package com.androidharness.app

import android.app.Application
import android.content.Context
import android.webkit.WebView
import androidx.compose.foundation.ComposeFoundationFlags
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.room.Room
import com.androidharness.app.agent.AgentEngine
import com.androidharness.app.agent.TaskOrchestrator
import com.androidharness.app.agent.TodoStore
import com.androidharness.app.data.ChatBackupManager
import com.androidharness.app.data.CheckpointStore
import com.androidharness.app.data.ImageStore
import com.androidharness.app.data.KeyStoreManager
import com.androidharness.app.data.ProviderRepository
import com.androidharness.app.data.SessionRepository
import com.androidharness.app.data.SettingsRepository
import com.androidharness.app.data.db.AppDatabase
import com.androidharness.app.llm.ProviderFactory
import com.androidharness.app.tools.ToolRegistry
import com.androidharness.app.workspace.WorkspaceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class HarnessApp : Application() {
    lateinit var container: AppContainer
        private set

    @OptIn(ExperimentalFoundationApi::class)
    override fun onCreate() {
        super.onCreate()
        // Paused LazyColumn prefetch crashes in LayoutNode.onChildRemoved when chat items change.
        ComposeFoundationFlags.isPausableCompositionInPrefetchEnabled = false
        WebView.enableSlowWholeDocumentDraw()
        container = AppContainer(this)
    }
}

class AppContainer(val appContext: Context) {
    /** Deep-link channel: run-result notifications deliver a session id here. */
    val pendingSessionId = kotlinx.coroutines.flow.MutableSharedFlow<String>(extraBufferCapacity = 1)

    /** Share-target channel: one ACTION_SEND payload awaiting the open chat. */
    val pendingShare = kotlinx.coroutines.flow.MutableStateFlow<com.androidharness.app.data.PendingShare?>(null)

    /** Build/test failure prompt waiting for a fresh chat to run it. */
    val pendingAgentPrompt = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    /** In-app nav channel: a screen asking Settings to scroll to a section. */
    val pendingSettingsScroll = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    val keys = KeyStoreManager(appContext)
    val settings = SettingsRepository(appContext)
    val providers = ProviderRepository(appContext, keys)
    val screenshotPolicy = com.androidharness.app.data.ScreenshotPolicy()

    private val db = Room.databaseBuilder(appContext, AppDatabase::class.java, "harness.db")
        .addMigrations(
            AppDatabase.MIGRATION_4_5, AppDatabase.MIGRATION_5_6,
            AppDatabase.MIGRATION_6_7, AppDatabase.MIGRATION_7_8,
            AppDatabase.MIGRATION_8_9, AppDatabase.MIGRATION_9_10, AppDatabase.MIGRATION_10_11, AppDatabase.MIGRATION_11_12, AppDatabase.MIGRATION_12_13, AppDatabase.MIGRATION_13_14,
        )
        .addCallback(AppDatabase.OVERSIZED_ROW_SANITIZER)
        // Only kicks in when no migration path exists (pre-v4 databases);
        // the v4→v5 path above preserves sessions and usage totals.
        .fallbackToDestructiveMigration(true)
        .build()
    val sessions = SessionRepository(db)
    val chatBackup = ChatBackupManager(db, appContext)
    val snippets = com.androidharness.app.data.SnippetRepository(db.dao())

    val sshConnections = com.androidharness.app.workspace.SshConnections(keys)
    val workspace = WorkspaceManager(appContext, db.dao(), sshConnections)
    val checkpoints = CheckpointStore(db.dao())
    val images = ImageStore(appContext)

    val todoStore = TodoStore()
    val repoMap = com.androidharness.app.repomap.RepoMapCache()
    private val fetchClient = OkHttpClient()
    val linuxEnv =
        com.androidharness.app.data.env.LinuxEnvironmentManager(appContext) { keys.githubToken() }
    val root = com.androidharness.app.data.env.RootManager(appContext)
    val shellRouter = com.androidharness.app.data.env.ShellTierRouter(appContext, root, linuxEnv)
    val codeGraph = com.androidharness.app.data.env.CodeGraphManager(linuxEnv, shellRouter)

    /**
     * Owns the locally installed @google/gemini-cli and the app-private
     * gemini-home that keeps its Google OAuth credentials across updates.
     */
    val gemini = com.androidharness.app.llm.GeminiManager(appContext, linuxEnv)

    init {
        // Package-set changes must invalidate the deployed-copy cache, or the
        // root tier keeps serving the old toolchain until a restart.
        linuxEnv.deployStateListener = { root.invalidateDeployState() }
        // The Gemini CLI provider is the one LlmProvider that is not built per
        // request: it needs the manager owning the installed binary, so it is
        // registered here before any chat can ask the factory for it.
        ProviderFactory.registerGeminiCliProvider(gemini)
    }

    val updates = com.androidharness.app.data.update.UpdateManager(appContext, root)
    val backgroundProcesses = com.androidharness.app.data.BgProcessStore(
        appContext, linuxEnv, root, workspaceRoot = workspace.appPrivateRoot,
    )

    @Volatile
    private var projectSkillsDir: java.io.File? = null
    private val disabledSkills = AtomicReference<Set<String>>(emptySet())
    private val webSearchProvider = AtomicReference("keyless")
    private val searchKeyMigrated = AtomicBoolean(false)

    /**
     * web_search backend config, resolved per call so Settings changes apply
     * to the very next search without a restart. Null = keyless engines.
     */
    val searchApiConfig: com.androidharness.app.tools.SearchApiConfig?
        get() {
            val provider = webSearchProvider.get()
            if (provider == "keyless") return null
            return keys.searchApiKey(provider)?.let {
                com.androidharness.app.tools.SearchApiConfig(provider, it)
            }
        }

    private val cavemanSettings = AtomicReference(com.androidharness.app.data.AppSettings())
    val skills = com.androidharness.app.skills.SkillStore(
        bundled = com.androidharness.app.skills.SkillAssets.load(appContext.assets),
        userDir = java.io.File(appContext.filesDir, "skills").apply { mkdirs() },
        projectDir = { projectSkillsDir },
        disabled = { disabledSkills.get() },
        optionalBundled = {
            if (cavemanSettings.get().cavemanInstalled) com.androidharness.app.caveman.CavemanPolicy.skills else emptyMap()
        },
    )
    val browser = com.androidharness.app.browser.BrowserController(appContext, images)
    val taskOrchestrator: TaskOrchestrator by lazy {
        TaskOrchestrator(appContext)
    }
    val registry = ToolRegistry.default(
        fetchClient, todoStore, backgroundProcesses, linuxEnv, root, shellRouter, skills, codeGraph,
        imageStore = images,
        browserController = browser,
        searchApi = { searchApiConfig },
        appContext = appContext,
        taskOrchestrator = taskOrchestrator,
    )
    val mcp = com.androidharness.app.tools.mcp.McpManager(appContext, linuxEnv, keys, codeGraph)
    val engine = AgentEngine(
        providerFactory = { config -> ProviderFactory.create(config) },
        registry = registry,
        checkpointer = checkpoints,
        imageStore = images,
        linuxEnv = linuxEnv,
        root = root,
        skills = skills,
        todoStore = todoStore,
        repoMap = repoMap,
        cavemanSettings = { settings.settings.first().also { cavemanSettings.set(it); disabledSkills.set(it.disabledSkills) } },
    )
    val runManager = com.androidharness.app.agent.RunManager(
        context = appContext,
        engine = engine,
        sessions = sessions,
        checkpoints = checkpoints,
        workspace = workspace,
        linuxEnv = linuxEnv,
        settings = settings,
        todoStore = todoStore,
        mcp = mcp,
        repoMap = repoMap,
    )
    val automation = com.androidharness.app.automation.AutomationManager(this)
    val terminal = com.androidharness.app.data.TerminalManager(appContext, linuxEnv, root, runManager)

    /**
     * Applies a GitHub token change end-to-end: re-materialize the prefix
     * copies (token file + gitconfig rewrite), then redeploy the shell-tier
     * toolchain so the new auth is live without an app restart.
     */
    suspend fun refreshGitHubAuth() = linuxEnv.refreshGitHub(root)

    init {
        // models.dev thinking-capability catalog: serve the cached copy
        // synchronously, then refresh in the background (weekly cadence).
        com.androidharness.app.llm.ModelsDev.load(appContext)
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            // Learned wire per Harness model (chat vs anthropic vs responses),
            // persisted by the first-request probe; mirrored into memory so
            // every request path reads it synchronously.
            providers.harnessWires.collect { com.androidharness.app.llm.HarnessProvider.pins = it }
        }
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            // The harness catalog is the static anonymous pool now, nothing to
            // fetch; only models.dev needs a background refresh.
            com.androidharness.app.llm.ModelsDev.refresh(appContext)
        }
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            settings.settings.collect {
                disabledSkills.set(it.disabledSkills)
                cavemanSettings.set(it)
                // The search key store moved to per-provider slots; attribute
                // the pre-split key to whichever provider was active first.
                if (searchKeyMigrated.compareAndSet(false, true)) {
                    keys.migrateLegacySearchKey(it.webSearchProvider)
                }
                webSearchProvider.set(it.webSearchProvider)
            }
        }
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            workspace.current.collect { fs ->
                projectSkillsDir = fs.shellRoot?.resolve(".harness/skills")
            }
        }
        // Regenerate the linker shims the moment the environment is ready: an
        // older format (broken argv[0] for coreutils applets) must not survive
        // an app update, and the header check makes this a no-op when current.
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            linuxEnv.state.collect {
                if (it is com.androidharness.app.data.env.EnvState.Ready) linuxEnv.ensureShims()
            }
        }
        // Eagerly deploy the root-executed toolchain copy the moment both the
        // Linux environment and root are ready, so every tier works from
        // the first command (foreground shell, background spawn, terminal).
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            combine(linuxEnv.state, root.state) { e, s -> e to s }
                .collect { (e, s) ->
                    if (e is com.androidharness.app.data.env.EnvState.Ready &&
                        s == com.androidharness.app.data.env.RootState.GRANTED
                    ) {
                        linuxEnv.ensureShellDeploy(root)
                    }
                }
        }
        // Self-heal prefixes installed by older builds: relink dangling
        // termux-absolute symlinks, rewrite Termux shebangs, resume installs
        // that were interrupted and reinstall packages whose binaries
        // vanished. Silent when the prefix is already healthy; network
        // failures never demote a Ready environment (retried next launch).
        kotlinx.coroutines.CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val repaired = linuxEnv.repairIfNeeded()
            // A repair changes prefix content (reinstalled pip, rewritten
            // shebangs) without necessarily changing the package-set hash, and
            // StateFlow conflates the unchanged Ready state so the deploy
            // collector above never re-fires, re-stage the shell-tier copy
            // explicitly so it picks the fixes up.
            if (repaired != null &&
                root.state.value == com.androidharness.app.data.env.RootState.GRANTED
            ) {
                linuxEnv.ensureShellDeploy(root)
            }
        }
    }
}
