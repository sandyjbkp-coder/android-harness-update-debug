package com.androidharness.app.data.update

import android.content.Context
import com.androidharness.app.data.env.RootManager
import com.androidharness.app.data.env.RootState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * In-app updater backed by GitHub Releases.
 *
 * Flow: check latest release -> if its version is NEWER than the running one,
 * surface a dialog (with clickable changelog links parsed from the release
 * body) -> download the .apk asset with progress -> install:
 *
 *  - Root granted: `pm install -r` runs silently
 *    as the shell uid (the APK is staged under the app's external files dir,
 *    which the shell uid demonstrably reads, the toolchain deploy uses the
 *    exact same path family).
 *  - No root: hand the downloaded file to the system package installer
 *    (the standard "express" sideload flow with the platform's own UI).
 */
class UpdateManager(
    private val context: Context,
    private val root: com.androidharness.app.data.env.RootManager,
) {

    enum class Phase { IDLE, CHECKING, UP_TO_DATE, AVAILABLE, DOWNLOADING, INSTALLING, DONE, ERROR }

    data class LatestRelease(
        val tag: String,
        val name: String,
        /** Release body/description, may contain plain links or a linked changelog.md. */
        val body: String,
        val htmlUrl: String,
        val apkUrl: String?,
        val apkName: String?,
        val apkBytes: Long,
    )

    sealed interface Step {
        data object Idle : Step
        data object Checking : Step
        data class UpToDate(val current: String) : Step
        data class Available(val release: LatestRelease) : Step
        data class Downloading(val release: LatestRelease, val percent: Int, val mb: Float, val totalMb: Float) : Step
        data class Installing(val release: LatestRelease, val viaRoot: Boolean) : Step
        data class Done(val viaRoot: Boolean) : Step
        data class Error(val message: String, val release: LatestRelease? = null) : Step
    }

    private val _step = MutableStateFlow<Step>(Step.Idle)
    val step: StateFlow<Step> = _step.asStateFlow()

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    /** Where downloads stage: shared external files dir (shell-uid readable). */
    private val updateDir: File
        get() = File(
            context.getExternalFilesDir(null) ?: context.filesDir,
            "update",
        ).apply { mkdirs() }

    /** Manual flag so a Settings-triggered check always surfaces its result. */
    @Volatile private var manualCheck = false

    suspend fun check(manual: Boolean = false): Unit = withContext(Dispatchers.IO) {
        manualCheck = manual || manualCheck
        val current = runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
        }.getOrDefault("")
        val alreadyRunning = when (val s = _step.value) {
            is Step.Checking, is Step.Downloading, is Step.Installing -> true
            else ->
                // Auto checks shouldn't nag again over an existing dialog.
                !manual && (s is Step.Available || s is Step.Error)
        }
        if (alreadyRunning) return@withContext
        try {
            _step.value = Step.Checking
            val release = fetchLatest()
            val newer = release != null && isNewer(release.name.ifBlank { release.tag }, current)
            when {
                release == null -> _step.value =
                    if (manualCheck) Step.Error("No published release found yet.") else Step.Idle
                newer -> _step.value = Step.Available(release)
                manualCheck -> _step.value = Step.UpToDate(current)
                else -> _step.value = Step.Idle
            }
        } catch (e: Exception) {
            if (manualCheck) {
                _step.value = Step.Error(e.message ?: "Update check failed")
            } else {
                _step.value = Step.Idle
            }
        } finally {
            manualCheck = false
        }
    }

    fun dismiss() {
        _step.value = Step.Idle
    }

    private fun fetchLatest(): LatestRelease? {
        // NOTE: /releases/latest EXCLUDES prereleases, every release in this
        // repo ships as pre-release, so query the list instead. It arrives
        // newest-first (by created date); drafts are skipped.
        val req = Request.Builder()
            .url(RELEASES_API)
            .header("Accept", "application/vnd.github+json")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("GitHub API HTTP ${resp.code}")
            val arr = json.parseToJsonElement(resp.body!!.string()).jsonArray
            for (el in arr) {
                val root = el.jsonObject
                if (root["draft"]?.jsonPrimitive?.content == "true") continue
                return parseRelease(root) ?: continue
            }
            return null
        }
    }

    private fun parseRelease(root: kotlinx.serialization.json.JsonObject): LatestRelease? {
        val tag = root["tag_name"]?.jsonPrimitive?.content.orEmpty().removePrefix("v")
        val name = root["name"]?.jsonPrimitive?.content.orEmpty()
        val body = root["body"]?.jsonPrimitive?.content.orEmpty()
        val url = root["html_url"]?.jsonPrimitive?.content.orEmpty()
        var apkUrl: String? = null
        var apkName: String? = null
        var apkBytes = 0L
        root["assets"]?.jsonArray?.forEach { el ->
            val a = el.jsonObject
            val assetName = a["name"]?.jsonPrimitive?.content.orEmpty()
            if (assetName.endsWith(".apk", ignoreCase = true)) {
                apkUrl = a["browser_download_url"]?.jsonPrimitive?.content
                apkName = assetName
                apkBytes = a["size"]?.jsonPrimitive?.content?.toLongOrNull() ?: 0L
            }
        }
        if (tag.isBlank()) return null
        return LatestRelease(tag, name.ifBlank { tag }, body, url, apkUrl, apkName, apkBytes)
    }

    /** Downloads the release APK, reporting progress through [step]. */
    private fun download(release: LatestRelease): File {
        val out = File(updateDir, release.apkName ?: "harness-update.apk")
        val req = Request.Builder().url(release.apkUrl!!).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("Download failed: HTTP ${resp.code}")
            val body = resp.body ?: throw IllegalStateException("Empty download")
            val total = body.contentLength().takeIf { it > 0 } ?: release.apkBytes
            body.byteStream().use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        read += n
                        if (total > 0) {
                            val mb = read / 1_048_576f
                            val totalMb = total / 1_048_576f
                            _step.value = Step.Downloading(
                                release,
                                ((read * 100) / total).toInt().coerceIn(0, 100),
                                (mb * 10).toInt() / 10f,
                                (totalMb * 10).toInt() / 10f,
                            )
                        }
                    }
                }
            }
        }
        return out
    }

    /**
     * Runs the install leg. Root takes priority; system installer is the
     * fallback. Returns after handing off ([onNeedUserInstaller] opens the
     * platform flow), the caller drives UI state around this.
     */
    suspend fun startUpdate(
        release: LatestRelease,
        onOpenSystemInstaller: (File) -> Unit,
        onOpenUnknownSourcesSettings: () -> Unit,
    ): Unit = withContext(Dispatchers.IO) {
        val apk = runCatching { download(release) }.getOrElse { e ->
            _step.value = Step.Error(e.message ?: "Download failed", release)
            return@withContext
        }
        val viaRoot = tryRootInstall(apk)
        if (viaRoot) {
            _step.value = Step.Done(viaRoot = true)
            apk.delete()
            return@withContext
        }
        _step.value = Step.Installing(release, viaRoot = false)
        // System path requires the unknown-sources grant first.
        val canInstall = if (android.os.Build.VERSION.SDK_INT >= 26) {
            context.packageManager.canRequestPackageInstalls()
        } else true
        if (!canInstall) {
            _step.value = Step.Error(NEED_INSTALL_PERMISSION, release)
            onOpenUnknownSourcesSettings()
            return@withContext
        }
        onOpenSystemInstaller(apk)
    }

    /** Called from the Activity once the user granted unknown-sources. */
    suspend fun continueSystemInstall(release: LatestRelease, apk: File, onOpenSystemInstaller: (File) -> Unit) {
        _step.value = Step.Installing(release, viaRoot = false)
        onOpenSystemInstaller(apk)
    }

    private suspend fun tryRootInstall(apk: File): Boolean {
        if (root.state.value != RootState.GRANTED) return false
        // pm is an Android system binary, so this is the SYSTEM_ROOT path:
        // a uid-0 shell with system PATH and no Linux prefix libraries.
        val r = root.runSystem(
            script = "pm install -r " + RootManager.shellQuote(apk.absolutePath),
            timeoutMs = 120_000,
            maxBytes = 4_000,
        )
        return r.exitCode == 0 &&
            !r.output.contains("Failure", ignoreCase = true) &&
            !r.stderr.contains("Exception", ignoreCase = true)
    }

    companion object {
        const val RELEASES_API = "https://api.github.com/repos/Sanuu7/AndroidHarness/releases"
        const val NEED_INSTALL_PERMISSION =
            "Allow installs from this source to continue. Grant it, then tap Update again."

        /**
         * Compares the numeric core of [remote] against [current]: "0.3-alpha" ->
         * 0.3, "Alpha-v0.3" -> 0.3, "v1.2.3" -> 1.2.3. Anything unparsable never
         * prompts (no nagging on odd tags); equal versions never prompt.
         */
        internal fun isNewer(remote: String, current: String): Boolean {
            val r = parseParts(remote) ?: return false
            val c = parseParts(current) ?: return false
            val n = maxOf(r.size, c.size)
            for (i in 0 until n) {
                val rv = r.getOrElse(i) { 0 }
                val cv = c.getOrElse(i) { 0 }
                if (rv != cv) return rv > cv
            }
            return false
        }

        /**
         * Pulls the version core out of arbitrary release names/tags by scanning
         * digit runs anywhere in the string and taking the last: "Alpha-v0.3"
         * (the repo's tag shape), "0.3-alpha", "v1.2.3", "Alpha v0.31".
         */
        private fun parseParts(version: String): List<Int>? =
            VERSION_CORE_RE.findAll(version).lastOrNull()
                ?.value?.split('.')?.map { it.toIntOrNull() ?: 0 }

        private val VERSION_CORE_RE = Regex("""\d+(?:\.\d+)*""")
    }
}
