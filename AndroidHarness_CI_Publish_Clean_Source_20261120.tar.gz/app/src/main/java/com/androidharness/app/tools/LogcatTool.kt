package com.androidharness.app.tools

import com.androidharness.app.data.env.RootManager
import com.androidharness.app.data.env.RootState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Built-in agent tool to read Android system and application logs.
 * When root is granted, queries run as uid 0, so they see device-wide logs
 * across all apps, system services, and crashes.
 * In fallback mode (no root), runs as the app UID (best-effort, app's own logs).
 */
class ReadLogcatTool(
    private val root: RootManager? = null,
    private val runner: LogcatRunner = DefaultLogcatRunner(root),
) : Tool {
    override val name = "read_logcat"
    override val description =
        "Read recent Android logcat logs with optional filtering by log level, tag, package name, buffer, or keyword. " +
        "Useful for debugging Android app crashes, ANRs, runtime exceptions, and system events. " +
        "When root is granted, captures device-wide logs; otherwise captures logs available to the app."

    override val parametersSchema = Schema.obj(
        mapOf(
            "lines" to Schema.integer("Number of recent log lines to retrieve (default 100, max 1000)."),
            "level" to Schema.string("Minimum log level: V (Verbose), D (Debug), I (Info), W (Warn), E (Error), F (Fatal). Default is V."),
            "tag" to Schema.string("Filter logs by specific tag (e.g., 'AndroidRuntime', 'ActivityManager', or custom app tag)."),
            "package_name" to Schema.string("Filter logs by Android package name (e.g., 'com.example.app'). Resolves its PID if running or filters matching log lines."),
            "buffer" to Schema.string("Logcat ring buffer to read from: 'main', 'system', 'crash', 'events', 'radio', 'all', or 'default'. Default is 'default' (main, system, crash)."),
            "filter" to Schema.string("Case-insensitive keyword/substring to filter the output lines."),
        ),
    )

    override val isReadOnly = true

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult =
        withContext(Dispatchers.IO) {
            val linesCount = (args["lines"]?.jsonPrimitive?.intOrNull ?: 100).coerceIn(1, MAX_LINES)
            val level = parseLevel(args["level"]?.jsonPrimitive?.content)
            val tag = args["tag"]?.jsonPrimitive?.content?.trim()?.takeIf { it.isNotEmpty() }
            val pkg = args["package_name"]?.jsonPrimitive?.content?.trim()?.takeIf { it.isNotEmpty() }
            val buffer = args["buffer"]?.jsonPrimitive?.content?.trim()?.takeIf { it.isNotEmpty() }
            val filter = args["filter"]?.jsonPrimitive?.content?.trim()?.takeIf { it.isNotEmpty() }

            val query = LogcatQuery(
                lines = linesCount,
                level = level,
                tag = tag,
                packageName = pkg,
                buffer = buffer,
                filter = filter,
            )

            val runResult = runner.runLogcat(query)
            if (!runResult.ok) {
                return@withContext ToolResult(false, runResult.output)
            }

            var outputLines = runResult.output.lines()

            // Filter in-memory if substring requested or if package_name was provided but no PID was available
            if (!filter.isNullOrBlank()) {
                outputLines = outputLines.filter { it.contains(filter, ignoreCase = true) }
            }
            if (!pkg.isNullOrBlank() && runResult.pid == null) {
                // If we couldn't resolve PID, do best-effort text matching for package name
                outputLines = outputLines.filter { it.contains(pkg, ignoreCase = true) }
            }

            // Cap lines to requested count after post-filtering
            val finalLines = if (outputLines.size > linesCount) {
                outputLines.takeLast(linesCount)
            } else {
                outputLines
            }

            val truncatedOutput = finalLines.joinToString("\n").trim()
            val prefixNote = buildString {
                if (runResult.tierNote != null) {
                    append(runResult.tierNote)
                    append("\n")
                }
                if (pkg != null) {
                    if (runResult.pid != null) {
                        append("[filtered by PID ${runResult.pid} for package $pkg]\n")
                    } else {
                        append("[package $pkg is not currently running; matched text occurrences]\n")
                    }
                }
            }

            val finalOutput = if (truncatedOutput.isBlank()) {
                "${prefixNote}No matching logcat entries found for query: lines=$linesCount, level=$level" +
                    (if (tag != null) ", tag=$tag" else "") +
                    (if (pkg != null) ", package=$pkg" else "") +
                    (if (buffer != null) ", buffer=$buffer" else "") +
                    (if (filter != null) ", filter='$filter'" else "")
            } else {
                prefixNote + truncatedOutput
            }

            ToolResult(true, finalOutput.take(MAX_OUTPUT_CHARS))
        }

    private fun parseLevel(raw: String?): String {
        val upper = raw?.trim()?.uppercase() ?: return "V"
        return when (upper) {
            "V", "VERBOSE" -> "V"
            "D", "DEBUG" -> "D"
            "I", "INFO" -> "I"
            "W", "WARN", "WARNING" -> "W"
            "E", "ERROR" -> "E"
            "F", "FATAL" -> "F"
            else -> "V"
        }
    }

    companion object {
        const val MAX_LINES = 1000
        const val MAX_OUTPUT_CHARS = 65536
    }
}

data class LogcatQuery(
    val lines: Int,
    val level: String,
    val tag: String? = null,
    val packageName: String? = null,
    val buffer: String? = null,
    val filter: String? = null,
)

data class LogcatRunResult(
    val ok: Boolean,
    val output: String,
    val pid: String? = null,
    val tierNote: String? = null,
)

interface LogcatRunner {
    suspend fun runLogcat(query: LogcatQuery): LogcatRunResult
}

class DefaultLogcatRunner(
    private val root: RootManager?,
) : LogcatRunner {

    override suspend fun runLogcat(query: LogcatQuery): LogcatRunResult {
        val isPrivileged = root != null && root.state.value == RootState.GRANTED

        // Resolve PID for package if specified
        var pid: String? = null
        if (!query.packageName.isNullOrBlank()) {
            pid = resolvePid(query.packageName, isPrivileged)
        }

        val cmdArgs = buildLogcatArgs(query, pid)

        return if (isPrivileged) {
            runPrivilegedLogcat(cmdArgs, pid)
        } else {
            runLocalLogcat(cmdArgs, pid)
        }
    }

    private suspend fun resolvePid(packageName: String, isPrivileged: Boolean): String? {
        val pidCmd = arrayOf("/system/bin/pidof", packageName)
        val raw = if (isPrivileged) {
            root?.runSystem(
                script = pidCmd.joinToString(" ") { RootManager.shellQuote(it) },
                timeoutMs = 3_000,
                maxBytes = 256,
            )?.output
        } else {
            runCatching {
                val p = ProcessBuilder(*pidCmd).start()
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor(2, TimeUnit.SECONDS)
                out
            }.getOrNull()
        }
        val firstPid = raw?.trim()?.split(Regex("\\s+"))?.firstOrNull { it.all { c -> c.isDigit() } }
        return firstPid?.takeIf { it.isNotEmpty() }
    }

    internal fun buildLogcatArgs(query: LogcatQuery, pid: String?): List<String> {
        val hasFilters = !query.tag.isNullOrBlank() ||
            query.level != "V" ||
            !query.filter.isNullOrBlank() ||
            !query.packageName.isNullOrBlank()

        if (!hasFilters) {
            val args = mutableListOf("/system/bin/logcat", "-d", "-t", query.lines.toString())
            if (!query.buffer.isNullOrBlank() && query.buffer != "default") {
                args.addAll(listOf("-b", query.buffer))
            }
            return args
        }

        val logcatArgs = mutableListOf("/system/bin/logcat", "-d")
        if (!query.buffer.isNullOrBlank() && query.buffer != "default") {
            logcatArgs.addAll(listOf("-b", query.buffer))
        }
        if (pid != null) {
            logcatArgs.add("--pid=$pid")
        }
        val filterspec = when {
            !query.tag.isNullOrBlank() -> listOf("${query.tag}:${query.level}", "*:S")
            query.level != "V" -> listOf("*:${query.level}")
            else -> emptyList()
        }
        logcatArgs.addAll(filterspec)

        val f1 = query.filter.orEmpty()
        val f2 = if (pid == null && !query.packageName.isNullOrBlank()) query.packageName else ""

        val script = "lines=\$1; f1=\$2; f2=\$3; shift 3; " +
            "if [ -n \"\$f1\" ] && [ -n \"\$f2\" ]; then " +
            "/system/bin/logcat \"\$@\" | /system/bin/grep -F -i -- \"\$f1\" | /system/bin/grep -F -i -- \"\$f2\" | /system/bin/tail -n \"\$lines\"; " +
            "elif [ -n \"\$f1\" ]; then " +
            "/system/bin/logcat \"\$@\" | /system/bin/grep -F -i -- \"\$f1\" | /system/bin/tail -n \"\$lines\"; " +
            "elif [ -n \"\$f2\" ]; then " +
            "/system/bin/logcat \"\$@\" | /system/bin/grep -F -i -- \"\$f2\" | /system/bin/tail -n \"\$lines\"; " +
            "else " +
            "/system/bin/logcat \"\$@\" | /system/bin/tail -n \"\$lines\"; " +
            "fi; " +
            "exit \${PIPESTATUS[0]}"

        return listOf(
            "/system/bin/sh",
            "-c",
            script,
            "_",
            query.lines.toString(),
            f1,
            f2,
        ) + logcatArgs
    }

    private suspend fun runPrivilegedLogcat(args: List<String>, pid: String?): LogcatRunResult {
        // logcat is an Android system binary, so this deliberately uses the
        // SYSTEM_ROOT path: a root shell with system PATH and no prefix
        // LD_LIBRARY_PATH, which is where /system/bin/logcat belongs.
        val result = root?.runSystem(
            script = args.joinToString(" ") { RootManager.shellQuote(it) },
            timeoutMs = 15_000,
            maxBytes = ReadLogcatTool.MAX_OUTPUT_CHARS,
        ) ?: return LogcatRunResult(false, "Root runner returned no result.")

        return if (result.exitCode == 0 || result.output.isNotEmpty()) {
            LogcatRunResult(
                ok = true,
                output = result.output,
                pid = pid,
                tierNote = null,
            )
        } else {
            LogcatRunResult(
                ok = false,
                output = "logcat failed with exit code ${result.exitCode}: ${result.stderr.ifEmpty { result.output }}",
            )
        }
    }

    private fun runLocalLogcat(args: List<String>, pid: String?): LogcatRunResult {
        return try {
            val process = ProcessBuilder(args).start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val sb = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                sb.append(line).append('\n')
                if (sb.length >= ReadLogcatTool.MAX_OUTPUT_CHARS) break
            }
            val finished = process.waitFor(15, TimeUnit.SECONDS)
            val output = sb.toString()
            val exitCode = if (finished) process.exitValue() else -1
            if (exitCode != 0 && output.isBlank()) {
                val stderr = runCatching { process.errorStream.bufferedReader().readText() }.getOrDefault("")
                return LogcatRunResult(
                    ok = false,
                    output = "logcat failed with exit code $exitCode: ${stderr.ifEmpty { output }}",
                )
            }

            val tierNote = "[note: running without root; modern Android only permits reading this app's own logs. Grant root in Settings → Terminal for device-wide logcat]"

            LogcatRunResult(
                ok = true,
                output = output,
                pid = pid,
                tierNote = tierNote,
            )
        } catch (e: Exception) {
            LogcatRunResult(
                ok = false,
                output = "Failed to run logcat: ${e.message}",
            )
        }
    }
}
