package com.androidharness.app.data.env

import android.content.Context
import android.os.Build
import android.system.Os
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import com.androidharness.app.tools.ShellPolicy
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.CompressorStreamFactory
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class PkgMeta(
    val name: String,
    val version: String,
    val depends: List<String>,
    val filename: String,
    val size: Long,
    val sha256: String,
    val description: String = "",
    val installedSize: Long = 0L,
)

/** Parses the Debian Packages index served by the Termux repository. */
object PackageIndex {
    fun parse(text: String): Map<String, PkgMeta> {
        val out = mutableMapOf<String, PkgMeta>()
        text.split(Regex("\\n\\n")).forEach { block ->
            val fields = mutableMapOf<String, String>()
            var current: String? = null
            block.lines().forEach { line ->
                when {
                    line.isEmpty() -> Unit
                    line.startsWith(" ") -> {
                        val key = current ?: return@forEach
                        fields[key] = (fields[key] ?: "") + "\n" + line.trim()
                    }
                    else -> {
                        val i = line.indexOf(':')
                        if (i > 0) {
                            current = line.substring(0, i)
                            fields[current!!] = line.substring(i + 1).trim()
                        }
                    }
                }
            }
            val name = fields["Package"] ?: return@forEach
            val filename = fields["Filename"] ?: return@forEach
            val depends = (fields["Depends"] ?: "")
                .split(',')
                .map { it.trim().substringBefore('(').trim().split('|').first().trim() }
                .filter { it.isNotBlank() }
            val desc = fields["Description"]?.lines()?.firstOrNull()?.trim().orEmpty()
            out[name] = PkgMeta(
                name = name,
                version = fields["Version"] ?: "",
                depends = depends,
                filename = filename,
                size = fields["Size"]?.toLongOrNull() ?: 0L,
                sha256 = fields["SHA256"] ?: "",
                description = desc,
                installedSize = fields["Installed-Size"]?.toLongOrNull() ?: 0L,
            )
        }
        return out
    }
}

/**
 * Termux packages ship absolute symlinks into their own build prefix
 * (/data/data/com.termux/files/usr/...); inside this app's prefix those
 * dangle (bzcmp, bzless, and many man-page links). Rewrites them as paths
 * relative to the link's directory, pointing at the same file inside our
 * prefix, which also keeps the installed tree relocatable for the
 * shell-user re-deploy.
 */
internal object TermuxLinkRewrite {
    private const val TERMUX_USR = "/data/data/com.termux/files/usr/"

    /**
     * @param linkName raw symlink target from the package archive
     * @param linkPath where the symlink itself lives inside the prefix (e.g. "bin/bzcmp")
     * @return rewritten relative target, or null when nothing needs rewriting
     */
    fun relativeTarget(linkName: String, linkPath: String): String? {
        if (!linkName.startsWith(TERMUX_USR)) return null
        val inside = linkName.removePrefix(TERMUX_USR)
        val depth = linkPath.trim('/').split('/').dropLast(1).count { it.isNotEmpty() }
        return "../".repeat(depth) + inside
    }
}

/**
 * Termux packages ship scripts whose shebang points into the Termux build
 * prefix (/data/data/com.termux/files/usr/...). Inside this app those paths
 * never exist, so the scripts have to be fixed at extraction:
 *
 *  - the Android-bridge wrapper commands (termux-tools: pm, cmd, am, settings,
 *    …) are dead weight here, they shadow the real /system binaries and die
 *    with exit 126, so they are dropped;
 *  - language tooling (bin/pip3, lib/node_modules/npm/bin/npm-cli.js, git's
 *    libexec helper scripts, …) is genuinely needed, and the SHELL-uid tier
 *    execs scripts directly (no linker shims exist there, so the kernel reads
 *    the shebang). Their first line is rewritten to point into the deployed
 *    prefix at /data/local/tmp, where the interpreter ELF is directly
 *    executable. The app-uid tier never consults shebangs (W^X exec is
 *    blocked and every command goes through the linker shims), so the same
 *    file works in both tiers.
 */
internal object TermuxShebangs {
    private const val TERMUX_USR = "/data/data/com.termux/files/usr/"

    /** Match marker for any Termux-prefixed shebang (even outside files/usr). */
    const val TERMUX_PREFIX_MARK = "#!/data/data/com.termux/"

    /** Android-bridge wrapper commands shipped by termux-tools. */
    val SYSTEM_WRAPPERS = setOf(
        "am", "bmgr", "bu", "cmd", "content", "device_config", "dpm", "dumpsys",
        "getprop", "ime", "input", "log", "logcat", "media", "mount", "notify",
        "pm", "settings", "setprop", "sm", "svc", "uiautomator", "umount",
        "wm", "start", "stop",
    )

    /**
     * True when [name] is a termux-tools Android-bridge wrapper. The wrappers
     * are POSIX shell scripts, they all carry a Termux bin/sh shebang, so a
     * non-shell script that happens to share a name (pm, log, …) is tooling
     * that should be rewritten, not dropped.
     */
    fun isWrapperScript(name: String, firstLine: String): Boolean =
        firstLine.startsWith("#!${TERMUX_USR}bin/sh") && name in SYSTEM_WRAPPERS

    /**
     * Rewrites a Termux-absolute shebang into [deployedPrefix] (this build's
     * deployed copy); null when the line cannot be repaired (not under
     * files/usr, or still references the Termux prefix after rewriting).
     * busybox provides `env` only as an applet in bin/applets, so env-style
     * launchers route through that.
     */
    fun rewrittenFirstLine(firstLine: String, deployedPrefix: String): String? {
        if (!firstLine.startsWith("#!$TERMUX_USR")) return null
        var line = "#!$deployedPrefix/" + firstLine.removePrefix("#!$TERMUX_USR")
        line = line.replaceFirst("$deployedPrefix/bin/env ", "$deployedPrefix/bin/applets/env ")
        return if (line.contains("/data/data/com.termux")) null else line
    }
}

/**
 * Termux's git embeds its SHELL_PATH (/data/data/com.termux/files/usr/bin/sh)
 * in the ELF: git runs helpers, hooks and aliases through `sh -c` using that
 * literal, and outside Termux the path never exists, so every spawn dies with
 * "cannot exec" (gh repo clone's credential helper, for example). No env var
 * can redirect it (unlike GIT_EXEC_PATH/GIT_TEMPLATE_DIR), so the string is
 * patched in place at extraction: a same-length replacement keeps the ELF's
 * layout intact and NUL padding terminates the shorter path. /system/bin/sh
 * is exec-able from both shell tiers.
 */
internal object TermuxShellPath {
    private const val TERMUX_SHELL = "/data/data/com.termux/files/usr/bin/sh"
    private const val NEUTRAL_SHELL = "/system/bin/sh"
    private val NEEDLE = TERMUX_SHELL.toByteArray(Charsets.UTF_8)
    private val REPLACEMENT = NEUTRAL_SHELL.toByteArray(Charsets.UTF_8)

    /** True when [relPath] is git territory whose ELFs may embed SHELL_PATH. */
    fun appliesTo(relPath: String): Boolean =
        relPath.startsWith("bin/git") || relPath.startsWith("libexec/git-core/")

    /** Replaces every occurrence in [bytes] in place; returns how many. */
    fun patchBytes(bytes: ByteArray): Int {
        var count = 0
        var i = 0
        val last = bytes.size - NEEDLE.size
        while (i <= last) {
            var j = 0
            while (j < NEEDLE.size && bytes[i + j] == NEEDLE[j]) j++
            if (j == NEEDLE.size) {
                REPLACEMENT.copyInto(bytes, i)
                for (k in REPLACEMENT.size until NEEDLE.size) bytes[i + k] = 0
                count++
                i += NEEDLE.size
            } else {
                i++
            }
        }
        return count
    }

    /**
     * Patches [file] in place; returns the number of occurrences rewritten.
     * ELF-gated: git's scripts under libexec/ are handled by the shebang
     * rewriter, and a text file containing the literal must not be touched.
     */
    fun patch(file: File): Int = runCatching {
        val bytes = file.readBytes()
        if (bytes.size < 4 || bytes[0] != 0x7f.toByte() || bytes[1] != 'E'.code.toByte() ||
            bytes[2] != 'L'.code.toByte() || bytes[3] != 'F'.code.toByte()
        ) {
            return 0
        }
        val n = patchBytes(bytes)
        if (n > 0) file.writeBytes(bytes)
        n
    }.getOrDefault(0)
}

sealed interface EnvState {
    data object NotInstalled : EnvState
    /** Fetching the package index and resolving the closure; no bytes yet. */
    data object Preparing : EnvState
    data class Downloading(val index: Int, val total: Int, val pkg: String) : EnvState
    data class Installing(val index: Int, val total: Int, val pkg: String) : EnvState
    data object Ready : EnvState
    data class Failed(val message: String) : EnvState
}

/**
 * Git environment that keeps the bundled (Termux-built) git out of an
 * unreadable system config. See [LinuxEnvironmentManager.gitSystemConfigEnv]
 * for why this exists; the decision is pure so it can be tested without a
 * device.
 *
 * - A readable system config is named explicitly (GIT_CONFIG_SYSTEM), so git
 *   cannot fall back to the path compiled into the binary.
 * - Otherwise the system scope is switched off entirely (GIT_CONFIG_NOSYSTEM),
 *   which is what git does by itself when there is no /etc/gitconfig.
 *
 * The Termux prefix is preferred when that file exists: it is the copy this
 * build's git was actually compiled to read, so honouring it keeps behaviour
 * identical to a normal Termux install whenever it is readable.
 */
internal fun gitSystemConfigEnvOf(
    termuxSystemConfig: File,
    systemConfig: File,
): Map<String, String> {
    val candidate = if (termuxSystemConfig.isFile) termuxSystemConfig else systemConfig
    return if (candidate.isFile && candidate.canRead()) {
        mapOf("GIT_CONFIG_NOSYSTEM" to "0", "GIT_CONFIG_SYSTEM" to candidate.absolutePath)
    } else {
        mapOf("GIT_CONFIG_NOSYSTEM" to "1")
    }
}

/**
 * git's system GITATTRIBUTES scope, the sibling of [gitSystemConfigEnvOf] and
 * the same re-rooting problem: the bundled Termux-built git resolves the
 * attributes file next to the system config, and an unreadable one costs three
 * to five stderr lines on EVERY git tool call:
 *   warning: unable to access '…/etc/gitattributes': Permission denied
 * (on-device QA, 2026-09-17; the system config's fatal twin was fixed earlier
 * by naming a readable file explicitly).
 *
 * git has no equivalent of GIT_CONFIG_SYSTEM for attributes, so a file that
 * cannot be read is switched off instead with GIT_ATTR_NOSYSTEM, the attributes
 * twin of GIT_CONFIG_NOSYSTEM (git_attr_system_is_enabled() in git's attr.c).
 * Nothing in the harness reads system attributes, and a readable file is left
 * exactly as it is.
 */
internal fun gitSystemAttributesEnvOf(
    termuxSystemAttributes: File,
    systemAttributes: File,
): Map<String, String> {
    val candidate = if (termuxSystemAttributes.isFile) termuxSystemAttributes else systemAttributes
    return if (candidate.isFile && candidate.canRead()) emptyMap()
    else mapOf("GIT_ATTR_NOSYSTEM" to "1")
}

/**
 * Installs a self-contained Linux userspace (bash, coreutils, git, python,
 * node…) into the app's private storage, sourced from the public Termux
 * package repository. No root, no external app required.
 */
class LinuxEnvironmentManager(
    private val context: Context,
    /** Master GitHub token from the app's encrypted settings (never stored in the prefix). */
    private val githubTokenProvider: () -> String? = { null },
) {

    val prefix: File = File(context.filesDir, "linux")

    /** This build's deployed copy (exec-able by the shell uid). See [deployedBaseFor]. */
    val tmpBase: String = deployedBaseFor(context.packageName)
    val tmpPrefix: String = "$tmpBase/linux"

    private val marker = File(prefix, ".harness-installed")
    private val tempDir = File(context.cacheDir, "deb-download").apply { mkdirs() }

    /**
     * Real cwd for shell commands when the active workspace is a SAF folder.
     * Lives on shared storage (external files dir) so the root shell uid can
     * enter it too, so the old private-storage location is migrated once.
     */
    val shellFallbackRoot: File = run {
        val newDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "shell-workspace")
        val oldDir = File(context.filesDir, "shell-workspace")
        if (oldDir.exists() && !newDir.exists() && oldDir != newDir) {
            runCatching { oldDir.renameTo(newDir) }
        }
        newDir.apply { mkdirs() }
    }

    /**
     * The app's private data directory (/data/user/0/<pkg>). Processes that run
     * as other uids (the root shell uid) cannot enter it, so shell routing
     * uses this to decide which tier can reach the working directory.
     */
    val internalDataRoot: File = context.dataDir

    init {
        // An older build left these world-writable; restore private defaults.
        runCatching { Os.chmod(context.dataDir.absolutePath, 0x1C0 /* 0700 */) }
        runCatching { Os.chmod(context.filesDir.absolutePath, 0x1C0 /* 0700 */) }
        // Bug 1 fix: materialize the bundled Mozilla CA store into the prefix
        // so curl/python/git/node in the shell tier verify TLS by default.
        com.androidharness.app.tools.NetTls.ensureInstalled(prefix, context)
        // Bug 2 fix: provision the designated exec-capable scratch dirs.
        runCatching { ensureScratchDirs() }
        // GitHub auth (stress-test C1 fix): the toolchain HOME is wiped on
        // every reinstall/redeploy, so ~/.gh-token must be re-materialized
        // from the app's encrypted settings at every start.
        runCatching { materializeGitHub() }
    }

    private val _state = MutableStateFlow<EnvState>(
        if (marker.exists()) EnvState.Ready else EnvState.NotInstalled
    )
    val state: StateFlow<EnvState> = _state

    val isReady: Boolean get() = _state.value is EnvState.Ready

    /**
     * Notified whenever the installed package set changes: the app wires this
     * to RootManager.invalidateDeployState so the deployed copy is
     * re-checked (and redeployed if the hash moved) on the next root
     * command, without it, an in-place package update would keep serving the
     * old toolchain until an app restart.
     */
    var deployStateListener: (() -> Unit)? = null

    @Volatile private var lastDeployVerifyAt = 0L

    /**
     * Self-heal for the deployed shell-tier copy: re-compares the deployed
     * hash at most once per [DEPLOY_REVERIFY_INTERVAL_MS], so a vanished or
     * corrupted .harness-hash, or any external staging drift, is noticed and
     * repaired by the normal deploy path without waiting for an app restart.
     * No-op when the hash matches the staging state.
     */
    suspend fun verifyDeployedCopyThrottled(root: RootManager) {
        if (root.isDeployInProgress()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastDeployVerifyAt < DEPLOY_REVERIFY_INTERVAL_MS) return
        lastDeployVerifyAt = now
        if (!isReady || !root.isGranted()) return
        runCatching { ensureShellDeploy(root) }
            .onFailure { Log.e(TAG, "periodic deployed-copy verification failed", it) }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Base packages for a usable coding shell (git pulls its own deps). */
    val corePackages = listOf("bash", "busybox", "ca-certificates", "git")

    /** Everything a coding agent may need, used by the chat install card. */
    val fullPackages = corePackages + listOf("gh", "python", "python-pip", "nodejs", "npm")

    /** Installs [wanted] plus their full dependency closure. Resumes after interruptions. */
    suspend fun install(wanted: List<String>) {
        if (_state.value is EnvState.Ready && wanted.all { installedContains(it) }) return
        withContext(Dispatchers.IO) {
            // Serialized: concurrent installs race the read-modify-write on the
            // package marker and can silently drop entries, which later reads
            // as phantom "missing" packages.
            installMutex.withLock {
                if (_state.value is EnvState.Ready && wanted.all { installedContains(it) }) return@withLock
                installLocked(wanted)
            }
        }
    }

    private val installMutex = Mutex()

    private var cachedIndex: Map<String, PkgMeta>? = null
    private val indexMutex = Mutex()

    /** Returns the parsed repository package index, caching it in memory. */
    suspend fun getPackageIndex(forceRefresh: Boolean = false): Map<String, PkgMeta> = withContext(Dispatchers.IO) {
        indexMutex.withLock {
            if (!forceRefresh && cachedIndex != null) return@withLock cachedIndex!!
            val text = fetchText(indexUrl())
            val index = PackageIndex.parse(text)
            cachedIndex = index
            index
        }
    }

    /** Searches available repository packages by name or description. */
    suspend fun searchPackages(query: String): List<PkgMeta> = withContext(Dispatchers.IO) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return@withContext emptyList()
        val index = runCatching { getPackageIndex() }.getOrDefault(emptyMap())
        index.values.filter {
            it.name.lowercase().contains(q) || it.description.lowercase().contains(q)
        }.sortedWith(
            compareBy<PkgMeta> {
                when {
                    it.name.equals(q, ignoreCase = true) -> 0
                    it.name.lowercase().startsWith(q) -> 1
                    it.name.lowercase().contains(q) -> 2
                    else -> 3
                }
            }.thenBy { it.name }
        )
    }

    /** Returns metadata for a package by name, or null if unknown. */
    suspend fun getPackageMeta(name: String): PkgMeta? = withContext(Dispatchers.IO) {
        val index = runCatching { getPackageIndex() }.getOrNull()
        index?.get(name)
    }

    /**
     * Downloads one repository package's .deb with checksum verification,
     * without installing it. For features that ship a separate runtime next to
     * the toolchain (the CodeGraph page pulls a Node 24 for its own use) and
     * must not claim the package in the installed marker.
     */
    suspend fun downloadPackageDeb(name: String, dest: File): Boolean = withContext(Dispatchers.IO) {
        val pkg = getPackageMeta(name) ?: return@withContext false
        // The index is a network response, so its Filename field is untrusted:
        // keep the download URL inside the repo pool and the local file inside
        // the caller's directory.
        val fileField = pkg.filename
        val base = fileField.substringAfterLast('/')
        if (fileField.startsWith('/') || fileField.contains('\\') ||
            fileField.split('/').any { it.isEmpty() || it == "." || it == ".." } ||
            !base.endsWith(".deb")
        ) throw IllegalStateException("Unsafe package filename in the index: $fileField")
        dest.parentFile?.mkdirs()
        downloadVerified("$BASE_URL/$fileField", dest, pkg.sha256)
        true
    }

    /** Resolves which packages need to be downloaded/installed for [wanted] excluding already-installed ones. */
    suspend fun resolveClosure(wanted: List<String>): List<PkgMeta> = withContext(Dispatchers.IO) {
        val index = getPackageIndex()
        val already = installedPackages().toSet()
        resolve(index, wanted).filter { it.name !in already }
    }

    /**
     * Uninstalls an installed package. Core packages cannot be uninstalled.
     */
    suspend fun uninstallPackage(name: String): Boolean = withContext(Dispatchers.IO) {
        if (name in corePackages) throw IllegalArgumentException("Cannot uninstall core package '$name'")
        val installed = installedPackages().toMutableSet()
        if (name !in installed) return@withContext false
        installed.remove(name)
        marker.writeText(installed.joinToString("\n"))
        BINARY_PROOF[name]?.forEach { binRel ->
            File(prefix, binRel).delete()
        }
        ensureShims(force = true)
        runCatching { deployStateListener?.invoke() }
        true
    }

    private suspend fun installLocked(wanted: List<String>) {
        try {
            // React to the tap immediately: fetching the package index takes
            // seconds on mobile networks before the first package download.
            _state.value = EnvState.Preparing
            val index = getPackageIndex()
            val already = installedPackages().toSet()
            val unknown = wanted.filter { it !in index }
            if (unknown.isNotEmpty()) {
                throw IllegalArgumentException("Unknown package(s): ${unknown.joinToString(", ")}. Not found in repository.")
            }
            val closure = resolve(index, wanted).filter { it.name !in already }
            if (closure.isEmpty()) {
                markInstalled(wanted)
                _state.value = EnvState.Ready
                runCatching { deployStateListener?.invoke() }
                return
            }

            _state.value = EnvState.Downloading(0, closure.size, closure.first().name)
            closure.forEachIndexed { i, pkg ->
                _state.value = EnvState.Downloading(i, closure.size, pkg.name)
                // The index is parsed from the network response, so its Filename
                // field is untrusted: keep the download URL inside the repo pool
                // and the local file inside this temp dir.
                val fileField = pkg.filename
                val debBase = fileField.substringAfterLast('/')
                if (fileField.startsWith('/') || fileField.contains('\\') ||
                    fileField.split('/').any { it.isEmpty() || it == "." || it == ".." } ||
                    !debBase.endsWith(".deb")
                ) throw IllegalStateException("Unsafe package filename in the index: $fileField")
                val debFile = File(tempDir, debBase)
                downloadVerified("$BASE_URL/$fileField", debFile, pkg.sha256)
                _state.value = EnvState.Installing(i, closure.size, pkg.name)
                extractDeb(debFile)
                debFile.delete()
                // record progress per package so a killed install resumes
                markInstalled(listOf(pkg.name))
            }

            File(prefix, "home").mkdirs()
            File(prefix, "tmp").mkdirs()
            File(prefix, "etc/termux").mkdirs()
            markInstalled(wanted)
            ensureShims(force = true)
            _state.value = EnvState.Ready
            runCatching { deployStateListener?.invoke() }
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            _state.value = EnvState.Failed(e.message ?: "Install failed")
        }
    }

    private fun markInstalled(names: List<String>) {
        val current = installedPackages().toMutableSet()
        current.addAll(names)
        marker.writeText(current.joinToString("\n"))
    }

    suspend fun uninstall() = withContext(Dispatchers.IO) {
        runCatching { prefix.deleteRecursively() }
        runCatching { stagingDir.deleteRecursively() }
        _state.value = EnvState.NotInstalled
    }

    fun installedPackages(): List<String> =
        runCatching { marker.readText().lines().filter { it.isNotBlank() } }.getOrDefault(emptyList())

    fun installedContains(name: String): Boolean = installedPackages().any { it == name }

    /** Package name → binaries proving it is actually usable (any-of). */
    private val BINARY_PROOF: Map<String, List<String>> = mapOf(
        "bash" to listOf("bin/bash"),
        "busybox" to listOf("bin/busybox"),
        "git" to listOf("bin/git"),
        "gh" to listOf("bin/gh"),
        "python" to listOf("bin/python3", "bin/python"),
        "python-pip" to listOf("bin/pip", "bin/pip3"),
        "nodejs" to listOf("bin/node"),
        "npm" to listOf("bin/npm"),
        "ca-certificates" to listOf("etc/tls/cacert.pem"),
    )

    /**
     * What is missing from the installed environment, human-readable. Checks
     * BOTH the package marker and the binaries on disk, so a marker entry whose
     * binary vanished counts as missing (that was the silent no-op bug).
     */
    fun checkMissing(): String {
        val installed = installedPackages().toSet()
        val missingPkgs = fullPackages.filter { it !in installed }
        val missingBins = BINARY_PROOF.filterKeys { it in installed || it in fullPackages }
            .filterValues { progs -> progs.none { File(prefix, it).exists() } }
            .keys.toList()
        return when {
            missingPkgs.isEmpty() && missingBins.isEmpty() ->
                "All present: bash, git, gh, python, pip, node, npm."
            else -> buildString {
                if (missingPkgs.isNotEmpty()) {
                    append("Missing packages: ").append(missingPkgs.joinToString(", "))
                }
                if (missingBins.isNotEmpty()) {
                    if (isNotEmpty()) append(" · ")
                    append("Broken (marked installed but binary gone): ")
                        .append(missingBins.joinToString(", "))
                }
            }
        }
    }

    /**
     * Update / check-missing: installs anything absent, and REINSTALLS
     * packages whose marker entry exists but whose binaries are gone (a
     * half-broken prefix never repaired itself before, so the button looked
     * dead). Returns true when the environment is Ready afterwards.
     */
    suspend fun updateEnvironment(): Boolean = withContext(Dispatchers.IO) {
        val broken = brokenInstalledPackages()
        if (broken.isNotEmpty()) {
            // Un-mark the broken ones so install() re-downloads them.
            marker.writeText(installedPackages().filter { it !in broken }.joinToString("\n"))
        }
        install(fullPackages)
        isReady
    }

    /** Packages marked installed whose proof binary is gone from disk. */
    private fun brokenInstalledPackages(): List<String> = installedPackages().filter { pkg ->
        BINARY_PROOF[pkg]?.let { progs -> progs.none { File(prefix, it).exists() } } ?: false
    }

    /** Standard-set packages that are not usable right now: never installed, or marked installed with the binaries gone. */
    private fun incompletePackages(): List<String> {
        val installed = installedPackages().toSet()
        val missing = fullPackages.filter { it !in installed }
        return (missing + brokenInstalledPackages()).distinct()
    }

    // ------------------------------------------------------------------
    // Self-heal for prefixes installed by older builds
    //
    // Two legacy gaps: bundles installed before npm joined fullPackages
    // (node present, npm missing) and symlinks extracted verbatim from
    // termux packages pointing into /data/data/com.termux. Both are fixed
    // in place on app start; healthy prefixes are untouched.
    // ------------------------------------------------------------------

    /** True when an installed prefix has node but is missing npm. */
    fun needsRepair(): Boolean =
        marker.exists() &&
            File(prefix, "bin/node").exists() &&
            !File(prefix, "bin/npm").exists()

    /**
     * Packages that joined the default set after some installs already existed
     * (gh in the 2026-08-28 build). Existing installs get the one-time "fetch
     * the new packages" notice until they run Update; fresh installs never
     * see it because they install the whole set at once.
     */
    private val LATE_PACKAGES = listOf("gh")

    /** Packages from [LATE_PACKAGES] missing from an installed prefix. Empty = nothing to fetch. */
    fun latePackagesPending(): List<String> {
        if (!marker.exists()) return emptyList()
        return LATE_PACKAGES.filter { !installedContains(it) }
    }

    /** Repoints dangling termux-absolute symlinks in bin/ and bin/applets. */
    private fun repairLegacySymlinks(): Int {
        var fixed = 0
        for (dir in listOf(File(prefix, "bin"), File(prefix, "bin/applets"))) {
            dir.listFiles()?.forEach { f ->
                val link = runCatching { Os.readlink(f.absolutePath) }.getOrNull() ?: return@forEach
                val rewritten = TermuxLinkRewrite.relativeTarget(link, f.toRelativeString(prefix)) ?: return@forEach
                runCatching {
                    Os.remove(f.absolutePath)
                    Os.symlink(rewritten, f.absolutePath)
                }.onSuccess { fixed++ }
            }
        }
        return fixed
    }

    /**
     * Bug 3 fix (existing installs): Termux's Android-bridge wrapper scripts
     * in bin/ (pm, cmd, am, settings, ...) shadow the real /system binaries
     * and die with exit 126; prefixes installed before the extract-time fix
     * are cleaned here on app start. Other bin scripts carrying a
     * Termux-absolute shebang (pip, …) are repaired in place instead: their
     * first line is rewritten into the deployed shell-tier prefix. Returns
     * (removed, rewritten) counts.
     */
    private fun purgeDeadTermuxShims(): Pair<Int, Int> {
        var removed = 0
        var rewritten = 0
        val binDir = File(prefix, "bin")
        binDir.listFiles()?.forEach { f ->
            if (!f.isFile) return@forEach
            if (f.isElf()) return@forEach
            val text = runCatching { f.readText() }.getOrNull() ?: return@forEach
            val nl = text.indexOf('\n')
            val firstLine = text.lineSequence().firstOrNull()?.trim() ?: ""
            if (!firstLine.startsWith(TermuxShebangs.TERMUX_PREFIX_MARK)) return@forEach
            val repaired = TermuxShebangs.rewrittenFirstLine(firstLine, tmpPrefix)
            if (repaired != null && !TermuxShebangs.isWrapperScript(f.name, firstLine)) {
                runCatching {
                    f.writeText(repaired + if (nl >= 0) text.substring(nl) else "")
                }.onSuccess { rewritten++ }
            } else if (runCatching { f.delete() }.getOrDefault(false)) {
                removed++
            }
        }
        return removed to rewritten
    }

    /**
     * Patches git ELFs still carrying the dead Termux SHELL_PATH (prefixes
     * installed before the extract-time fix). Only files already containing
     * the literal are rewritten, so healthy prefixes cost one read each.
     */
    private fun repairGitShellPaths(): Int {
        var patched = 0
        File(prefix, "bin").listFiles()?.forEach { f ->
            if (f.isFile && f.name.startsWith("git") && TermuxShellPath.patch(f) > 0) patched++
        }
        File(prefix, "libexec/git-core").listFiles()?.forEach { f ->
            if (f.isFile && TermuxShellPath.patch(f) > 0) patched++
        }
        return patched
    }

    /**
     * One-shot repair for existing installs, run at every app start:
     * relinks dangling symlinks, cleans/rewrites Termux shebangs, neutralizes
     * git's embedded Termux SHELL_PATH, and heals an incomplete toolchain,
     * packages whose install was interrupted never complete on their own (the
     * marker file exists, so the environment reads Ready), and packages whose
     * binaries vanished keep reporting "broken" forever. install() resumes
     * whatever is genuinely absent; late packages (LATE_PACKAGES) are excluded
     * so their one-time notice still governs them. A network failure never
     * demotes a Ready environment: the state is restored and the repair
     * retries on the next app start. Returns a summary, or null when nothing
     * needed fixing.
     */
    suspend fun repairIfNeeded(): String? {
        runCatching { gitGlobalConfig() }
        if (!marker.exists()) return null
        return withContext(Dispatchers.IO) {
            val relinked = repairLegacySymlinks()
            val (purged, shebangsRewritten) = purgeDeadTermuxShims()
            val shellPatched = repairGitShellPaths()
            val broken = brokenInstalledPackages()
            val missing = fullPackages.filter { !installedContains(it) && it !in latePackagesPending() }
            var healNote: String? = null
            if (broken.isNotEmpty() || missing.isNotEmpty()) {
                val wasReady = _state.value is EnvState.Ready
                if (broken.isNotEmpty()) {
                    // Un-mark the broken ones so install() re-downloads them.
                    marker.writeText(installedPackages().filter { it !in broken }.joinToString("\n"))
                }
                runCatching { install(fullPackages) }
                if (_state.value is EnvState.Failed && wasReady) _state.value = EnvState.Ready
                healNote = if (incompletePackages().isEmpty()) {
                    buildList {
                        if (broken.isNotEmpty()) add("reinstalled ${broken.joinToString(", ")}")
                        if (missing.isNotEmpty()) add("finished installing ${missing.joinToString(", ")}")
                    }.joinToString("; ").let { "restored toolchain ($it)" }
                } else {
                    "toolchain still incomplete (" + incompletePackages().joinToString(", ") +
                        "); will retry on next launch"
                }
            }
            if (relinked == 0 && purged == 0 && shebangsRewritten == 0 && shellPatched == 0 && healNote == null) {
                return@withContext null
            }
            // The repair changed prefix content without necessarily changing the
            // package-set hash; drop the staging marker so the next shell-tier
            // deploy re-stages instead of trusting the stale tarball.
            runCatching { stagingMarker.delete() }
            ensureShims()
            buildString {
                if (relinked > 0) append("relinked ").append(relinked).append(" dangling symlinks")
                if (purged > 0) {
                    if (isNotEmpty()) append("; ")
                    append("removed ").append(purged).append(" dead Termux shim(s) shadowing system binaries")
                }
                if (shebangsRewritten > 0) {
                    if (isNotEmpty()) append("; ")
                    append("rewrote ").append(shebangsRewritten)
                        .append(" Termux shebang(s) into the deployed prefix")
                }
                if (shellPatched > 0) {
                    if (isNotEmpty()) append("; ")
                    append("patched ").append(shellPatched)
                        .append(" git binary(ies) with a working shell path")
                }
                if (healNote != null) append(if (isEmpty()) "" else "; ").append(healNote)
            }.ifBlank { null }
        }
    }

    /** Environment for spawned processes (PATH/LD_LIBRARY_PATH/HOME/…). */
    fun processEnv(): Map<String, String> = buildMap {
        put("PATH", "${prefix.absolutePath}/bin:${prefix.absolutePath}/bin/applets:/system/bin:/system/xbin:/vendor/bin")
        put("LD_LIBRARY_PATH", "${prefix.absolutePath}/lib")
        put("HOME", "${prefix.absolutePath}/home")
        put("TMPDIR", "${prefix.absolutePath}/tmp")
        put("PREFIX", prefix.absolutePath)
        val termuxExec = File(prefix, "lib/libtermux-exec.so")
        if (termuxExec.exists()) {
            put("LD_PRELOAD", termuxExec.absolutePath)
            put("TERMUX__PREFIX", prefix.absolutePath)
        }
        put("TERM", "xterm-256color")
        put("LANG", "C.UTF-8")
        // The bundled (Termux-built) git warns "templates not found" on every
        // init because it looks under its old build prefix. Point it at the
        // templates shipped in our prefix, or disable templates if absent.
        put("GIT_TEMPLATE_DIR", gitTemplatesDir().absolutePath)
        // Same re-rooting problem for git's exec helpers (git-remote-https,
        // git-upload-pack…): its compiled-in exec path points at the old
        // Termux prefix. Without this, HTTPS clones die with
        // "remote helper 'https' aborted session".
        put("GIT_EXEC_PATH", File(prefix, "libexec/git-core").absolutePath)
        // Bug 5 fix: a generated global config marks every repo safe, so
        // plain shell git inside a uid=2000-owned checkout never hits
        // "detected dubious ownership". The same config carries the commit
        // identity + GitHub token rewrite (see gitGlobalConfig).
        put("GIT_CONFIG_GLOBAL", gitGlobalConfig().absolutePath)
        put("HARNESS_GIT_CONFIG", gitGlobalConfig().absolutePath)
        // Bug fix: the Termux-built git also reads a SYSTEM config from its old
        // prefix, where reading is denied and git exits 128 before running.
        putAll(gitSystemConfigEnv())
        // Same re-rooting, non-fatal version: an unreadable system
        // gitattributes file only prints a warning on every git call.
        putAll(gitSystemAttributesEnv())
        // bash sources this for `bash -c`: shims make every toolchain binary
        // runnable despite the W^X exec restriction on app-private files.
        if (shimFile.exists()) put("BASH_ENV", shimFile.absolutePath)
        putAll(tlsEnvVars())
        // OpenSSL-based tools read the config path they were built with, which
        // for these Termux builds is /data/data/com.termux/...: unreadable from
        // this app, and EACCES rather than missing when the Termux app is
        // installed, which Node refuses to start over.
        File(prefix, com.androidharness.app.tools.NetTls.OPENSSL_CONF_RELATIVE_PATH)
            .takeIf { it.isFile }
            ?.let { put("OPENSSL_CONF", it.absolutePath) }
        // Bug 2 fix: tell every spawned shell where exec-capable scratch lives.
        // This env serves APP-uid processes: they cannot write /data/local/tmp
        // (SELinux), so they get the app-private mirror; the privileged tier's
        // tmpProcessEnv exports the shared tmp scratch instead.
        put("HARNESS_SCRATCH", appPrivateScratch.absolutePath)
    }

    // ------------------------------------------------------------------
    // Bug 2 fix: exec-capable scratch dirs
    //
    // The workspace usually lives on shared storage (FUSE), which does not
    // preserve POSIX exec bits (chmod +x is a no-op: files stay -rw-rw----)
    // and cannot host symlinks, so JDK/Gradle/native binaries extracted there
    // fail with "Permission denied" and tarballs containing symlinks fail to
    // extract. These scratch dirs live on filesystems that support both:
    //
    //  - SCRATCH_TMP (/data/local/tmp/androidharness-scratch): 0700 shell-owned
    //    tmpfs/ext4, writable by the root shell tier (and adb).
    //  - the app-private mirror under /data/data/<pkg>/files/.harness-scratch:
    //    fallback when SELinux denies tmp access; the app-uid linker
    //    workaround makes binaries here runnable.
    //
    // The shell sandbox has a deliberate carve-out for exactly these paths
    // (ShellPolicy) and env vars advertise them to every spawned shell.
    // ------------------------------------------------------------------

    /** Creates and permission-opens the exec-capable scratch dirs. Idempotent. */
    fun ensureScratchDirs() {
        // Root-owned and 0700: every legitimate user (root exec, adb) runs
        // as the shell uid, so loosening the mode only widens the attack
        // surface; the app uid is walled off from /data/local/tmp by DAC and
        // SELinux regardless of the mode bits.
        val tmpScratch = File(ShellPolicy.SCRATCH_TMP)
        tmpScratch.mkdirs()
        runCatching { Os.chmod(tmpScratch.absolutePath, 0x1C0 /* 0700 */) }
        // App-private fallback for this build's package id: the ONLY location
        // the app uid can reliably write (SELinux denies app-writes to
        // /data/local/tmp even with a permissive mode).
        appPrivateScratch.mkdirs()
    }

    /**
     * Scratch dir usable by THIS app's uid for direct writes (tar extraction
     * etc.). App-private, so both package flavors map to their own copy.
     */
    val appPrivateScratch: File = File(context.filesDir, ".harness-scratch")

    /**
     * TLS trust vars (Bug 1 fix): point curl/python/git/node at the CA bundle
     * materialized into the prefix. Falls back to the system store path when
     * the bundled asset could not be provisioned.
     */
    fun tlsEnvVars(): Map<String, String> {
        val dir = runCatching { File(prefix, "etc/tls") }.getOrNull()
        val preferred = File(prefix, com.androidharness.app.tools.NetTls.BUNDLE_RELATIVE_PATH)
        val path = when {
            preferred.isFile -> preferred.absolutePath
            dir != null && dir.isDirectory ->
                File(dir, "cacert.pem").absolutePath
            else -> "/system/etc/security/cacerts" // last resort: anchors dir hint
        }
        return com.androidharness.app.tools.NetTls.envVars(path)
    }

    /** Empty (templates disabled) when the prefix has no git-core templates. */
    private fun gitTemplatesDir(): File =
        File(prefix, "share/git-core/templates").takeIf { it.isDirectory } ?: File("")

    /**
     * Bug 5 fix: global git config marking every repository safe, plus the
     * GitHub materialization (stress-test C1/C2/M6): a commit identity so
     * fresh clones can commit, and a token insteadOf rewrite as the credential
     * transport (credential helpers cannot exec in this toolchain). The exact
     * desired content is recomputed and written back whenever it drifts, so a
     * token saved in Settings takes effect without reinstalling anything.
     */
    /**
     * Master GitHub token from the app's encrypted settings, for tools that
     * report GitHub state (doctor, env_status). Null when none is configured.
     */
    fun githubToken(): String? = runCatching { githubTokenProvider() }.getOrNull()

    fun gitGlobalConfig(): File {
        val f = File(prefix, "etc/gitconfig")
        val desired = GitHubProvision.gitConfigBody(githubToken())
        if (!f.exists() || f.readText() != desired) {
            f.parentFile?.mkdirs()
            f.writeText(desired)
        }
        return f
    }

    /**
     * git's SYSTEM config scope for every process the harness spawns.
     *
     * The bundled git is Termux-built, so it resolves its system config to
     * /data/data/com.termux/files/usr/etc/gitconfig. When the Termux app is
     * installed that file EXISTS and is mode 600 inside another app's private
     * data, so the root shell uid reads EACCES rather than ENOENT and git
     * dies before doing any work:
     *   fatal: unable to access '…/etc/gitconfig': Permission denied
     * exit 128, on every subcommand that reads config (on-device QA, 2026-09-17).
     * Same re-rooting family as GIT_TEMPLATE_DIR / GIT_EXEC_PATH / OPENSSL_CONF
     * above, and the same remedy: never let git wander into the old prefix.
     *
     * Nothing in the harness relies on system-level git settings (safe.directory,
     * the commit identity and the token insteadOf rewrite all live in
     * GIT_CONFIG_GLOBAL), so an unreadable system config is simply skipped via
     * GIT_CONFIG_NOSYSTEM, git's own switch for "there is no system config".
     * A readable one is named explicitly so a differently-rooted binary cannot
     * pick a path the probe never checked.
     */
    fun gitSystemConfigEnv(): Map<String, String> = gitSystemConfigEnvOf(
        termuxSystemConfig = File(TERMUX_SYSTEM_GITCONFIG),
        systemConfig = File(SYSTEM_GITCONFIG),
    )

    /** System gitattributes scope; see [gitSystemAttributesEnvOf]. */
    fun gitSystemAttributesEnv(): Map<String, String> = gitSystemAttributesEnvOf(
        termuxSystemAttributes = File(TERMUX_SYSTEM_GITATTRIBUTES),
        systemAttributes = File(SYSTEM_GITATTRIBUTES),
    )

    /** Re-writes the toolchain copies of the GitHub auth state. Idempotent. */
    fun materializeGitHub() {
        val token = githubToken()
        GitHubProvision.materializeTokenFile(prefix, token)
        GitHubProvision.materializeGhHosts(prefix, token)
        gitGlobalConfig()
    }

    /**
     * Called after the user saves/clears the GitHub token. Auth reaches the
     * shell tier through syncShellTierAuth (direct writes into the deployed
     * prefix, fast, and independent of the deploy machinery; logout used to
     * leave gh/git authenticated there when the full redeploy silently
     * failed). No re-stage happens here: the tarball excludes all auth files
     * (isAuthEntry), so token changes cannot make it stale, and a forced
     * re-tar of the whole prefix on every login/logout held the auth mutex
     * for tens of seconds and left the Settings UI stuck on "Connecting...".
     * Deploys re-stage via ensureShellDeploy when the package set changes.
     */
    suspend fun refreshGitHub(root: RootManager) = withContext(Dispatchers.IO) {
        materializeGitHub()
        if (root.isGranted()) {
            runCatching { syncShellTierAuth(root) }
                .onFailure { Log.e(TAG, "root-tier GitHub auth sync failed", it) }
        }
        // The staging/deploy state may have changed under the cached flag;
        // let the next root command re-verify the deployed hash.
        root.invalidateDeployState()
    }

    /**
     * Writes the current auth state straight into the DEPLOYED shell-tier
     * prefix: .gh-token, gh's hosts.yml and etc/gitconfig (which carries the
     * insteadOf rewrite). Payloads are base64-wrapped so tokens and config
     * bodies cannot break the shell quoting. The staging tarball carries no
     * auth at all ([isAuthEntry] excludes it), so this is the ONLY writer of
     * the deployed prefix's auth files, it runs on every auth change and
     * after every successful deploy.
     */
    private suspend fun syncShellTierAuth(root: RootManager) {
        if (!root.isTmpPrefixDeployed(deployedTag())) return
        val token = githubToken()
        val gitconfig = GitHubProvision.gitConfigBody(token)
        val hosts = GitHubProvision.ghHostsYaml(token)
        val script = buildString {
            fun writeB64(path: String, content: String) {
                val b64 = android.util.Base64.encodeToString(
                    content.toByteArray(Charsets.UTF_8),
                    android.util.Base64.NO_WRAP,
                )
                append("echo '$b64' | base64 -d > '$path' && chmod 600 '$path' && ")
            }
            append("mkdir -p '$tmpPrefix/etc' '$tmpPrefix/home/.config/gh' && ")
            writeB64("$tmpPrefix/etc/gitconfig", gitconfig)
            if (GitHubProvision.hasToken(token)) {
                writeB64("$tmpPrefix/home/.gh-token", token!!.trim() + "\n")
            } else {
                append("rm -f '$tmpPrefix/home/.gh-token' && ")
            }
            val hostsBody = hosts
            if (hostsBody != null) {
                writeB64("$tmpPrefix/home/.config/gh/hosts.yml", hostsBody)
            } else {
                append("rm -f '$tmpPrefix/home/.config/gh/hosts.yml' && ")
            }
            append("echo AUTH_SYNC_OK")
        }
        val r = root.runSystem(script = script, timeoutMs = 15_000, maxBytes = 1_000)
        if (r.exitCode != 0 || !r.output.contains("AUTH_SYNC_OK")) {
            error(
                "AUTH_SYNC_OK not confirmed (exit=${r.exitCode}, stderr=${r.stderr.take(200)})",
            )
        }
    }

    // ------------------------------------------------------------------
    // W^X workaround: per-binary linker shims
    //
    // On targetSdk 29+, execve() of app-data files is denied, so only the
    // outermost process can be launched via /system/bin/linker64. So a bare
    // `python3` or even `ls | head` from inside bash dies with EACCES. The
    // shim file defines a bash function per toolchain binary that re-routes
    // it through linker64, so plain command names work everywhere.
    // ------------------------------------------------------------------

    private val shimFile: File get() = File(prefix, "etc/harness-shims.sh")

    private fun linkerPath(): String? = when {
        File("/system/bin/linker64").exists() -> "/system/bin/linker64"
        File("/apex/com.android.runtime/bin/linker64").exists() -> "/apex/com.android.runtime/bin/linker64"
        File("/system/bin/linker").exists() -> "/system/bin/linker"
        else -> null
    }

    private fun File.isElf(): Boolean = runCatching {
        inputStream().use { ins ->
            val magic = ByteArray(4)
            ins.read(magic) == 4 &&
                magic[0] == 0x7f.toByte() && magic[1] == 'E'.code.toByte() &&
                magic[2] == 'L'.code.toByte() && magic[3] == 'F'.code.toByte()
        }
    }.getOrDefault(false)

    private fun shellQuote(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    /** (Re)generates the shim file when missing, forced, or emitted by an older format. */
    fun ensureShims(force: Boolean = false) {
        runCatching {
            LocaleCommand.ensureInstalled(prefix)
            val linker = linkerPath() ?: return
            val binDir = File(prefix, "bin")
            if (!binDir.isDirectory) return
            if (force) shimFile.delete()
            // Cheap freshness check: when current, only the header line is read.
            if (!force && shimFile.isFile &&
                runCatching { shimFile.bufferedReader().use { it.readLine() } }.getOrNull() == ShellShims.HEADER
            ) return
            val bash = File(binDir, "bash").absolutePath
            val nodeBin = File(binDir, "node").takeIf { it.exists() }?.absolutePath
            val pythonBin = (File(binDir, "python3").takeIf { it.exists() }
                ?: File(binDir, "python").takeIf { it.exists() })?.absolutePath
            val sb = StringBuilder()
            sb.append(ShellShims.HEADER).append('\n')
            sb.append("# routes every bundled binary through the dynamic linker (W^X exec fix)\n")

            fun addShim(file: File) {
                val isElf = file.isElf()
                val shebang = if (isElf) null
                else runCatching { file.bufferedReader().use { it.readLine() } }.getOrNull()?.trim()
                ShellShims.line(file.name, file.absolutePath, isElf, shebang, linker, bash, nodeBin, pythonBin)
                    ?.let { sb.append(it) }
            }

            binDir.listFiles()?.forEach { if (it.isFile || it.canonicalPath != it.absolutePath) addShim(it) }
            File(prefix, "bin/applets").listFiles()?.forEach { addShim(it) }

            shimFile.parentFile?.mkdirs()
            shimFile.writeText(sb.toString())
        }
    }

    /**
     * bash -c prelude that sources the shim file. bash 5.3 stopped sourcing
     * $BASH_ENV for `bash -c` (script execution still does), so loading must
     * be explicit or toolchain binaries die on W^X devices and multi-call
     * applets misbehave wherever scripts do source the file. Cheap when the
     * file is already current; empty when there is no bash toolchain or shim
     * file to load.
     */
    private fun shimPrelude(): String {
        ensureShims()
        val path = shimFile.takeIf { it.isFile }?.absolutePath ?: return ""
        return ". ${shellQuote(path)} 2>/dev/null; "
    }

    /**
     * Environment for the LINUX_ROOT (uid 0) tier, whose copy of the
     * toolchain lives in this build's own directory under
     * /data/local/tmp/androidharness.
     */
    fun tmpProcessEnv(): Map<String, String> = buildMap {
        put("PATH", "$tmpPrefix/bin:$tmpPrefix/bin/applets:/system/bin:/system/xbin:/vendor/bin")
        put("LD_LIBRARY_PATH", "$tmpPrefix/lib")
        put("HOME", "$tmpPrefix/home")
        put("TMPDIR", "$tmpPrefix/tmp")
        put("PREFIX", tmpPrefix)
        // Same derivation rule as the entries below, and the same trap: the
        // deployed copy carries the preload iff the app prefix does. Pointing
        // LD_PRELOAD at a file that is not there is worse than not setting it,
        // because the linker then refuses EVERY dynamically linked binary
        // (setsid, sh, bash) with `CANNOT LINK EXECUTABLE ... not found`, so
        // the whole tier looks broken instead of degraded.
        if (File(prefix, "lib/libtermux-exec.so").exists()) {
            put("LD_PRELOAD", "$tmpPrefix/lib/libtermux-exec.so")
        }
        put("TERMUX__PREFIX", tmpPrefix)
        put("TERM", "xterm-256color")
        put("LANG", "C.UTF-8")
        // Same templates fix as the app-side env, for the /data/local/tmp copy.
        // The app uid CANNOT stat inside the deployed prefix (it is chmod 700),
        // so deployed state is DERIVED from the app prefix: the deployed copy
        // is staged from this exact tree, so it has the templates iff this one
        // does. A live probe here silently broke after the 0700 hardening.
        put(
            "GIT_TEMPLATE_DIR",
            if (gitTemplatesDir().isDirectory) "$tmpPrefix/share/git-core/templates" else "",
        )
        // Re-rooted git needs its exec helpers (git-remote-https etc.) pointed
        // at our deployed copy or HTTPS remotes abort with a missing helper.
        put("GIT_EXEC_PATH", "$tmpPrefix/libexec/git-core")
        // Bug 5 fix: same safe.directory global config for the shell-uid
        // tier, written under the deployed prefix.
        put("GIT_CONFIG_GLOBAL", "$tmpPrefix/etc/gitconfig")
        put("HARNESS_GIT_CONFIG", "$tmpPrefix/etc/gitconfig")
        // Same unreadable-system-config fix as the app-side env: derived the
        // same way (the deployed copy is staged from this tree), and the
        // app uid cannot stat inside the 0700 deployed prefix to re-probe.
        putAll(gitSystemConfigEnv())
        // Same warning-only fix for the system gitattributes scope.
        putAll(gitSystemAttributesEnv())
        // Bug 1 fix: the deployed copy carries its own CA bundle; export the
        // standard TLS vars so curl/python/git/node verify certificates.
        // Same derivation rule: stageForShell ships the staged bundle (from
        // the app prefix or the bundled asset) and every deploy installs it,
        // so the deployed path is unconditional. Blindly statting it from the
        // app uid failed post-0700 and fell back to /system/etc/security/cacerts
        // (a DIRECTORY) which broke all privileged-tier TLS (git exit with
        // "error adding trust anchors", curl exit 77).
        putAll(com.androidharness.app.tools.NetTls.envVars("$tmpPrefix/etc/tls/cacert.pem"))
        // Same derivation rule as the CA bundle above: the deployed copy is
        // staged from this prefix, so it has the OpenSSL config iff this one
        // does, and statting the 0700 deployed prefix from the app uid would
        // silently report it missing.
        File(prefix, com.androidharness.app.tools.NetTls.OPENSSL_CONF_RELATIVE_PATH)
            .takeIf { it.isFile }
            ?.let { put("OPENSSL_CONF", "$tmpPrefix/${com.androidharness.app.tools.NetTls.OPENSSL_CONF_RELATIVE_PATH}") }
        // Bug 2 fix: exec-capable scratch location for the root tier.
        put("HARNESS_SCRATCH", ShellPolicy.SCRATCH_TMP)
        // The root shell that runs these commands is a plain su child and
        // cannot know which build deployed this copy, so it reads the prefix
        // paths from here instead of assuming the legacy shared directory.
        put("HARNESS_TMP_PREFIX", tmpPrefix)
        put("HARNESS_TMP_LIB", "$tmpPrefix/lib")
        put("HARNESS_TMP_BIN", "$tmpPrefix/bin")
    }

    // ------------------------------------------------------------------
    // Deploy to the root (uid 0) tier
    //
    // SELinux blocks the shell uid from reading the app's private data dir
    // entirely (chmod cannot fix it), and /sdcard is mounted noexec, so the
    // only working path is: prefix → tar.gz on shared storage (shell-readable)
    // → root untars into /data/local/tmp/androidharness (exec-able as uid 0).
    // ------------------------------------------------------------------

    private val stagingDir: File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, "linux-deploy")
    private val stagingTar: File get() = File(stagingDir, "prefix.tar.gz")
    private val stagingMarker: File get() = File(stagingDir, ".harness-staged")

    /**
     * Hash of the installed package set plus optional tools deployed with it. The GitHub token fingerprint is
     * deliberately NOT an input anymore: auth changes propagate to the shell
     * tier via syncShellTierAuth (direct file writes), and refreshGitHub
     * re-stages the tarball in the background so the staging copy never goes
     * stale. Pinning auth to full redeploys made every logout/login pay a
     * 30-60s untar and left the UI lagging.
     */
    fun packageSetHash(): String {
        val codeGraphVersion = runCatching {
            File(prefix, CODEGRAPH_VERSION_MARKER).readText().trim()
        }.getOrDefault("")
        val bundlePatchVersion = CodeGraphBundlePatches.VERSION
        return ("v20-codegraph-p$bundlePatchVersion\n$codeGraphVersion\n" + installedPackages().sorted().joinToString("\n"))
            .let { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } }
    }

    /** External tools installed into the prefix must refresh the staged/deployed copy too. */
    fun invalidateExternalToolDeploy() {
        runCatching { stagingMarker.delete() }
        runCatching { deployStateListener?.invoke() }
    }

    /**
     * Tag the deployed copy must carry to be usable: the package-set hash plus
     * the content hash of the exact tarball it was extracted from.
     *
     * The package set alone is not enough. When staging fails (or is skipped)
     * the deploy would still untar whatever tarball is on disk and stamp it
     * with the current package hash, and from then on the copy looks current
     * forever while its files are older than the environment built for them:
     * binaries started there die in the linker on libraries that moved or
     * appeared since. Including the staged content means a copy is only ever
     * trusted when it came from the same bytes the app is staging now.
     *
     * Null means "nothing can match": staging is behind the installed package
     * set, so the copy has to be re-staged and re-deployed.
     */
    fun deployedTag(): String? {
        val hash = packageSetHash()
        val lines = runCatching { stagingMarker.readText().lines() }.getOrDefault(emptyList())
        if (lines.getOrNull(0) != hash) return null
        val content = lines.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return "$hash $content"
    }

    private fun fileSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { b -> "%02x".format(b) }
    }

    /** Writes (or refreshes) the staging tarball on shared storage atomically. */
    fun stageForShell() {
        try {
            if (!File(prefix, "bin/bash").exists()) return
            LocaleCommand.ensureInstalled(prefix)
            // Bug 5 fix: the safe.directory config must exist before the
            // prefix is tarred, or the deployed copy exports a missing file.
            runCatching { gitGlobalConfig() }
            val hash = packageSetHash()
            // The marker's second line is the tarball's CONTENT hash: a
            // package-list fingerprint alone accepted a swapped tarball whose
            // marker was left untouched. A content mismatch re-stages from the
            // app-side prefix, overwriting whatever sits on shared storage.
            val markerLines = runCatching { stagingMarker.readText().lines() }.getOrDefault(emptyList())
            if (stagingTar.exists() &&
                markerLines.getOrNull(0) == hash &&
                markerLines.getOrNull(1) == fileSha256(stagingTar)
            ) return
            stagingDir.mkdirs()
            // Bug 1 fix: ship the CA bundle next to the tarball. The staging
            // dir lives on shared storage where the shell uid can read it, so
            // the privileged deploy can install the trust anchors as well.
            runCatching {
                val dst = File(stagingDir, "etc/tls/cacert.pem")
                dst.parentFile?.mkdirs()
                val src = File(prefix, com.androidharness.app.tools.NetTls.BUNDLE_RELATIVE_PATH)
                if (src.isFile) {
                    if (!dst.isFile || dst.length() != src.length()) src.copyTo(dst, overwrite = true)
                } else {
                    context.assets.open(com.androidharness.app.tools.NetTls.ASSET_PATH).use { input ->
                        java.io.FileOutputStream(dst).use { out -> input.copyTo(out) }
                    }
                }
            }
            val tmp = File(stagingDir, "prefix.tar.gz.tmp")
            // Clean up any stale temp file from a previous interrupted run
            if (tmp.exists()) tmp.delete()
            // Write tarball to temp file with full flush/fsync
            org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(
                java.util.zip.GZIPOutputStream(tmp.outputStream().buffered()),
            ).use { tar ->
                tar.setLongFileMode(org.apache.commons.compress.archivers.tar.TarArchiveOutputStream.LONGFILE_POSIX)
                writeTarEntries(prefix, "linux", tar)
            }
            // Ensure all data is on disk before atomic rename
            tmp.sync()
            // Atomic rename with FUSE fallback: renameTo can fail on Android's
            // FUSE-backed shared storage; fall back to copy + fsync + delete.
            var renamed = tmp.renameTo(stagingTar)
            if (!renamed) {
                // Fallback: copy + fsync + delete temp
                tmp.copyTo(stagingTar, overwrite = true)
                stagingTar.sync()
                // Verify the copy matches before cleaning up temp
                if (fileSha256(tmp) == fileSha256(stagingTar)) {
                    renamed = true
                }
                tmp.delete()
            }
            if (!renamed) {
                throw IOException("Failed to finalize staging tarball (rename+fallback both failed)")
            }
            // Verify the final tarball is readable and compute its hash
            val contentHash = fileSha256(stagingTar)
            // Write marker ONLY after final archive exists and hash is verified
            stagingMarker.writeText("$hash\n$contentHash")
            stagingMarker.sync()
        } catch (e: Exception) {
            // On ANY failure, delete invalid marker and temp to prevent stale state
            runCatching { stagingMarker.delete() }
            runCatching { File(stagingDir, "prefix.tar.gz.tmp").delete() }
            Log.e(TAG, "staging the shell-tier tarball failed; the deployed copy stays stale", e)
        }
    }

    /**
     * Ensures file data is flushed to storage (best-effort fsync).
     */
    private fun File.sync() {
        try {
            outputStream().use { it.fd.sync() }
        } catch (_: Exception) {
            // Best effort; ignore on unsupported filesystems
        }
    }

    /**
     * Auth-bearing files are deliberately EXCLUDED from the staging tarball:
     * it lives on shared storage and is the longest-lived, most widely
     * readable token copy on the device. The deployed prefix receives them
     * via [syncShellTierAuth] after every deploy, and the app prefix keeps
     * its own 0600 copies.
     */
    private fun isAuthEntry(name: String): Boolean {
        val rel = name.removePrefix("linux/")
        return rel == GitHubProvision.TOKEN_FILE ||
            rel == GitHubProvision.GH_HOSTS_FILE ||
            rel == "etc/gitconfig"
    }

    private fun writeTarEntries(
        dir: File,
        base: String,
        tar: org.apache.commons.compress.archivers.tar.TarArchiveOutputStream,
    ) {
        dir.listFiles()?.forEach { child ->
            val name = "$base/${child.name}"
            val link = runCatching { Os.readlink(child.absolutePath) }.getOrNull()
            if (link == null && !child.isDirectory && isAuthEntry(name)) return@forEach
            val entry = when {
                link != null -> org.apache.commons.compress.archivers.tar.TarArchiveEntry(
                    name,
                    org.apache.commons.compress.archivers.tar.TarArchiveEntry.LF_SYMLINK,
                ).apply {
                    linkName = link
                }
                child.isDirectory ->
                    // tar marks directories with a trailing slash, without which
                    // they extract as 0-byte files and children can't unpack.
                    org.apache.commons.compress.archivers.tar.TarArchiveEntry("$name/")
                else -> org.apache.commons.compress.archivers.tar.TarArchiveEntry(child, name)
            }
            entry.mode = when {
                link != null -> 0x1FF // 0777
                child.isDirectory -> 0x1ED // 0755
                child.canExecute() -> 0x1ED // 0755
                else -> 0x1A4 // 0644
            }
            if (child.isDirectory && link == null) {
                tar.putArchiveEntry(entry)
                tar.closeArchiveEntry()
                writeTarEntries(child, name, tar)
            } else {
                tar.putArchiveEntry(entry)
                if (link == null && child.isFile) {
                    // Root-side tooling (npm, python, node, codegraph) writes
                    // cache files into this prefix as root:root 0600. The app
                    // uid cannot read them, so reading the entry throws EACCES
                    // and aborted the ENTIRE staging (every deploy failed with
                    // "staging the shell-tier tarball failed"). They are pure
                    // caches: the shell tier regenerates its own, so skip them
                    // instead of failing the whole tarball.
                    val copied = runCatching {
                        child.inputStream().use { it.copyTo(tar) }
                    }.isSuccess
                    if (!copied) {
                        Log.w(TAG, "staging skipped unreadable entry: $name")
                    }
                }
                tar.closeArchiveEntry()
            }
        }
    }

    /**
     * Ensures the root-executed toolchain exists at /data/local/tmp/androidharness:
     * stages the prefix as a tarball on shared storage, then has root untar
     * it. No-op when the deployed copy matches the current package set.
     */
    private val deployLock = kotlinx.coroutines.sync.Mutex()

    suspend fun ensureShellDeploy(root: RootManager): Boolean {
        if (!isReady) return false
        return deployLock.withLock {
            // stageForShell gzips the ENTIRE prefix and ensureTmpPrefix waits on
            // a binder call that can run for minutes: never inherit the caller's
            // dispatcher (Settings reaches this from the main thread).
            withContext(Dispatchers.IO) {
                stageForShell()
                if (!stagingTar.exists()) return@withContext false
                // Deploy the tag computed AFTER staging, and skip the deploy
                // entirely when staging is behind the installed package set:
                // untarring a stale tarball and stamping it current is how a
                // broken copy becomes permanent (the marker then matches
                // forever, so nothing ever repairs it).
                val tag = deployedTag()
                if (tag == null) {
                    Log.e(TAG, "staging is behind the installed package set; skipping the shell-tier deploy")
                    return@withContext false
                }
                val ok = root.ensureTmpPrefix(stagingTar.absolutePath, tag)
                if (ok) {
                    // The tarball carries no auth (excluded at stage time), so a
                    // freshly deployed prefix has no gitconfig/token/hosts until
                    // they are written directly.
                    runCatching { syncShellTierAuth(root) }
                        .onFailure { Log.e(TAG, "post-deploy GitHub auth sync failed", it) }
                }
                ok
            }
        }
    }

    /** bash if installed, else null (callers fall back to toybox sh). */
    fun bashExecutable(): File? {
        val bash = File(prefix, "bin/bash")
        return bash.takeIf { it.canExecute() }
    }

    /**
     * Builds a shell process for [command]. Prefix binaries are launched
     * through the system dynamic linker: Android often refuses execve() on
     * app-data files (EACCES) even when the exec bits are set, while
     * linker64/linker map the ELF themselves, which is always permitted.
     * Falls back to direct exec, and toybox sh remains the last resort for
     * callers when the environment is not installed.
     */
    fun shellProcessBuilder(command: String): ProcessBuilder {
        val bash = bashExecutable()
        if (bash != null) {
            val linker = when (Build.SUPPORTED_ABIS.firstOrNull()) {
                "x86_64", "arm64-v8a" -> "/system/bin/linker64"
                else -> "/system/bin/linker"
            }
            val useLinker = File(linker).exists()
            val script = shimPrelude() + command
            val builder = if (useLinker) {
                ProcessBuilder(linker, bash.absolutePath, "-c", script)
            } else {
                ProcessBuilder(bash.absolutePath, "-c", script)
            }
            return builder.apply { environment().putAll(processEnv()) }
        }
        return ProcessBuilder("sh", "-c", command)
    }

    /**
     * Starts [command] with the best available shell: linker-launched bash,
     * then direct bash, then toybox sh. Never throws; [fallbackUsed] reports
     * which tier ended up running.
     */
    fun startShell(command: String, cwd: File): Pair<Process, ShellTier> {
        val envAvailable = bashExecutable() != null
        val script = if (envAvailable) shimPrelude() + command else command
        val setsid = when {
            File("/system/bin/setsid").exists() -> "/system/bin/setsid"
            File("/usr/bin/setsid").exists() -> "/usr/bin/setsid"
            else -> null
        }
        val shBin = if (File("/system/bin/sh").exists()) "/system/bin/sh" else "sh"
        val linker = when (Build.SUPPORTED_ABIS.firstOrNull()) {
            "x86_64", "arm64-v8a" -> "/system/bin/linker64"
            else -> "/system/bin/linker"
        }
        if (envAvailable && File(linker).exists()) {
            val p = runCatching {
                val bashPath = bashExecutable()!!.absolutePath
                val libPath = File(prefix, "lib").absolutePath
                val binPath = File(prefix, "bin").absolutePath
                val cmdList = if (setsid != null) {
                    listOf(
                        setsid,
                        shBin,
                        "-c",
                        "export LD_LIBRARY_PATH=\"$libPath:\$LD_LIBRARY_PATH\"; export PATH=\"$binPath:\$PATH\"; exec \"$linker\" \"$bashPath\" -c \"\$@\"",
                        "sh",
                        script,
                    )
                } else {
                    listOf(linker, bashPath, "-c", script)
                }
                ProcessBuilder(cmdList)
                    .directory(cwd)
                    .apply { environment().putAll(processEnv()) }
                    .start()
            }.getOrNull()
            if (p != null) return p to ShellTier.LINUX
        }
        if (envAvailable) {
            val p = runCatching {
                val bashPath = bashExecutable()!!.absolutePath
                val libPath = File(prefix, "lib").absolutePath
                val binPath = File(prefix, "bin").absolutePath
                val cmdList = if (setsid != null) {
                    listOf(
                        setsid,
                        shBin,
                        "-c",
                        "export LD_LIBRARY_PATH=\"$libPath:\$LD_LIBRARY_PATH\"; export PATH=\"$binPath:\$PATH\"; exec \"$bashPath\" -c \"\$@\"",
                        "sh",
                        script,
                    )
                } else {
                    listOf(bashPath, "-c", script)
                }
                ProcessBuilder(cmdList)
                    .directory(cwd)
                    .apply { environment().putAll(processEnv()) }
                    .start()
            }.getOrNull()
            if (p != null) return p to ShellTier.LINUX
        }
        val toyboxCmd = if (setsid != null) {
            listOf(setsid, "sh", "-c", command)
        } else {
            listOf("sh", "-c", command)
        }
        return ProcessBuilder(toyboxCmd).directory(cwd).start() to ShellTier.TOYBOX
    }

    enum class ShellTier { LINUX, TOYBOX }

    // ------------------------------------------------------------------

    private fun abiName(): String = when (Build.SUPPORTED_ABIS.firstOrNull()) {
        "arm64-v8a" -> "aarch64"
        "x86_64" -> "x86_64"
        "armeabi-v7a" -> "arm"
        "x86" -> "i686"
        else -> "aarch64"
    }

    private fun indexUrl(): String = "$BASE_URL/dists/stable/main/binary-${abiName()}/Packages"

    private fun fetchText(url: String): String =
        client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code} fetching repository index")
            resp.body?.string() ?: throw IllegalStateException("Empty repository index")
        }

    private fun resolve(index: Map<String, PkgMeta>, wanted: List<String>): List<PkgMeta> {
        val visited = LinkedHashSet<String>()
        fun visit(name: String) {
            if (name in visited) return
            val meta = index[name] ?: return
            meta.depends.forEach { visit(it) }
            visited += name
        }
        wanted.forEach { visit(it) }
        return visited.mapNotNull { index[it] }
    }

    private fun downloadVerified(url: String, dest: File, expectedSha256: String) {
        client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code} downloading $url")
            val body = resp.body ?: throw IllegalStateException("Empty download")
            val digest = MessageDigest.getInstance("SHA-256")
            dest.outputStream().use { out ->
                body.byteStream().use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        digest.update(buf, 0, n)
                    }
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (expectedSha256.isNotBlank() && !actual.equals(expectedSha256, ignoreCase = true)) {
                dest.delete()
                throw IllegalStateException("Checksum mismatch for ${dest.name}")
            }
        }
    }

    private fun extractDeb(deb: File) {
        ArArchiveInputStream(deb.inputStream().buffered()).use { ar ->
            var entry = ar.nextEntry
            while (entry != null && !entry.name.startsWith("data.tar")) {
                entry = ar.nextEntry
            }
            if (entry == null) throw IllegalStateException("No data archive in ${deb.name}")
            // Choose the decompressor from the extension, since auto-detection would
            // need a markable stream, which ArArchiveInputStream is not.
            val name = entry.name
            val input: java.io.InputStream = when {
                name.endsWith(".xz") || name.endsWith(".lzma") ->
                    CompressorStreamFactory().createCompressorInputStream(CompressorStreamFactory.XZ, ar)
                name.endsWith(".gz") ->
                    CompressorStreamFactory().createCompressorInputStream(CompressorStreamFactory.GZIP, ar)
                name.endsWith(".bz2") ->
                    CompressorStreamFactory().createCompressorInputStream(CompressorStreamFactory.BZIP2, ar)
                name.endsWith(".zst") ->
                    CompressorStreamFactory().createCompressorInputStream(CompressorStreamFactory.ZSTANDARD, ar)
                else -> ar // plain tar
            }
            TarArchiveInputStream(input).use { tar ->
                while (true) {
                    val e = tar.nextTarEntry ?: break
                    var rel = e.name.removePrefix("./").removePrefix("/")
                    val termuxPrefix = "data/data/com.termux/files/usr"
                    if (rel.startsWith(termuxPrefix)) {
                        rel = rel.removePrefix(termuxPrefix).removePrefix("/")
                    }
                    if (rel.isEmpty() || rel.startsWith("data/data")) continue
                    // Zip-slip guard: a crafted data.tar entry with .. segments
                    // would write outside the prefix. Real packages never ship them.
                    if (rel.split('/').any { it == ".." }) {
                        throw IllegalStateException("Refusing traversal path in ${deb.name}: ${e.name}")
                    }

                    val target = File(prefix, rel)
                    when {
                        e.isDirectory -> target.mkdirs()
                        e.isSymbolicLink -> {
                            target.parentFile?.mkdirs()
                            // Termux packages carry absolute symlinks into their
                            // own build prefix; rewrite them into our prefix or
                            // they arrive dangling (bzcmp, bzless, …).
                            val linkName = TermuxLinkRewrite.relativeTarget(e.linkName, rel) ?: e.linkName
                            runCatching { Os.symlink(linkName, target.absolutePath) }
                        }
                        else -> {
                            target.parentFile?.mkdirs()
                            // Peek the first bytes of every regular file (stream-safe:
                            // the bytes read are written back when the entry is kept).
                            // Scripts with a Termux-absolute shebang split three ways:
                            // the Android-bridge wrapper commands (bin/pm, cmd, am,
                            // settings, ...) are dropped entirely, they shadow real
                            // /system binaries and die with exit 126 (Bug 3 fix);
                            // language tooling (bin/pip3, lib/node_modules npm-cli.js,
                            // libexec git helper scripts, ...) gets its shebang
                            // REWRITTEN into the deployed shell-tier prefix so direct
                            // exec works where no linker shims exist; anything else is
                            // written verbatim (the app tier never consults shebangs,
                            // its commands run through the linker shims).
                            var skipWrite = false
                            val peeked = ByteArray(256)
                            val n = runCatching { tar.read(peeked, 0, peeked.size) }.getOrDefault(-1)
                            val entryText = if (n > 0) String(peeked, 0, n, Charsets.UTF_8) else ""
                            val firstLine = entryText.lineSequence().firstOrNull()?.trim() ?: ""
                            val rewritten = TermuxShebangs.rewrittenFirstLine(firstLine, tmpPrefix)
                            val binEntry = rel.startsWith("bin/") && !rel.contains("/applets/")
                            when {
                                TermuxShebangs.isWrapperScript(rel.substringAfterLast('/'), firstLine) ||
                                    (binEntry && firstLine.startsWith(TermuxShebangs.TERMUX_PREFIX_MARK) && rewritten == null) -> {
                                    // drain the rest of the entry without writing it
                                    tar.copyTo(object : java.io.OutputStream() {
                                        override fun write(b: Int) {}
                                    })
                                    skipWrite = true
                                }
                                rewritten != null && entryText.indexOf('\n') >= 0 -> {
                                    val nl = entryText.indexOf('\n')
                                    FileOutputStream(target).use { out ->
                                        out.write(rewritten.toByteArray(Charsets.UTF_8))
                                        out.write(peeked, nl, n - nl)
                                        tar.copyTo(out)
                                    }
                                    runCatching { Os.chmod(target.absolutePath, e.mode.toInt() and 0xFFF) }
                                    skipWrite = true
                                }
                                n > 0 -> {
                                    FileOutputStream(target).use { out ->
                                        out.write(peeked, 0, n)
                                        tar.copyTo(out)
                                    }
                                    runCatching { Os.chmod(target.absolutePath, e.mode.toInt() and 0xFFF) }
                                    // git's ELFs reference the dead Termux shell
                                    // path; neutralize it while the bytes are hot.
                                    if (TermuxShellPath.appliesTo(rel)) TermuxShellPath.patch(target)
                                    skipWrite = true
                                }
                                // n <= 0: empty entry, fall through to the plain writer
                            }
                            if (skipWrite) continue
                            FileOutputStream(target).use { out -> tar.copyTo(out) }
                            runCatching { Os.chmod(target.absolutePath, e.mode.toInt() and 0xFFF) }
                        }
                    }
                }
            }
        }
    }

    companion object {
        private const val TAG = "LinuxEnvironment"

        /** How often the deployed shell-tier copy is re-verified against the staging hash. */
        private const val DEPLOY_REVERIFY_INTERVAL_MS = 5 * 60 * 1000L

        private const val BASE_URL = "https://packages.termux.dev/apt/termux-main"

        /**
         * Where the bundled, Termux-built git looks for its SYSTEM config. The
         * binary carries /data/data/com.termux/files/usr as its prefix, and git
         * derives the system config path from that prefix rather than from
         * anything this app sets.
         */
        internal const val TERMUX_SYSTEM_GITCONFIG = "/data/data/com.termux/files/usr/etc/gitconfig"

        /** Standard system config location, for a git that is not Termux-built. */
        internal const val SYSTEM_GITCONFIG = "/etc/gitconfig"

        /** git's system-wide attributes file, next to the system config. */
        internal const val TERMUX_SYSTEM_GITATTRIBUTES = "/data/data/com.termux/files/usr/etc/gitattributes"

        internal const val SYSTEM_GITATTRIBUTES = "/etc/gitattributes"

        /** Parent directory of the shell-tier copies, one per installed build. */
        const val TMP_ROOT = "/data/local/tmp/androidharness"

        /**
         * Deployed copy owned by one build.
         *
         * Per applicationId on purpose. Several builds of Harness can be
         * installed at once (release plus debug, or an older install left
         * behind), and every build untars its own package set into the target.
         * At one shared path the last deploy wins: the tree then holds another
         * build's tools, and the libraries this build's environment names (its
         * preload, its own packages) are gone, so every binary started there
         * dies in the linker with
         * `CANNOT LINK EXECUTABLE ... library "..." not found`. A directory per
         * build makes the copy provably ours.
         */
        fun deployedBaseFor(packageName: String): String = "$TMP_ROOT/$packageName"

        /** Where builds deployed before they were namespaced left their copy. */
        const val LEGACY_TMP_PREFIX = "$TMP_ROOT/linux"
    }
}

/**
 * Pure shim-line builder for [LinuxEnvironmentManager.ensureShims], kept
 * separate so the emitted format is unit-testable without Android.
 */
internal object ShellShims {

    /**
     * Bumped whenever the emitted lines change so existing installs
     * regenerate (ensureShims compares only this header line).
     */
    const val HEADER = "# auto-generated by AndroidHarness (v3, locale): do not edit"

    /**
     * One shim: a bash function routing [name] through the dynamic [linker]
     * so W^X exec restrictions never bite. [entryPath] must be the bin entry
     * itself, NOT its canonical target: multi-call binaries (busybox,
     * coreutils, git) dispatch on argv[0], and a canonical path erases the
     * invoked name, which made every coreutils applet reject its flags
     * ("invalid option -- 'l'" for ls -la) and silenced echo and printf.
     * Non-ELF entries are scripts run under [bashPath], or the node/python
     * binary when their shebang asks for it and it exists.
     * Returns null when [name] is not a usable shell identifier.
     */
    fun line(
        name: String,
        entryPath: String,
        isElf: Boolean,
        shebang: String?,
        linker: String,
        bashPath: String,
        nodeBin: String?,
        pythonBin: String?,
    ): String? {
        // Function names must be sane identifiers.
        if (!name.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_.+:-]*"))) return null
        fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"
        val interp = when {
            shebang?.contains("node") == true -> nodeBin ?: bashPath
            shebang?.contains("python") == true -> pythonBin ?: bashPath
            else -> bashPath
        }
        val target = q(entryPath)
        return if (isElf) {
            "$name() { command $linker $target \"\$@\"; }\n"
        } else {
            "$name() { command $linker ${q(interp)} $target \"\$@\"; }\n"
        }
    }
}
